"""
AMNS India Email Module

"""
import os
import smtplib
import mimetypes
from binascii import hexlify
from email.mime.multipart import MIMEMultipart
from email import encoders
from email.mime.audio import MIMEAudio
from email.mime.base import MIMEBase
from email.mime.image import MIMEImage
from email.mime.text import MIMEText

version = '2020.07.22'


class PublishMail:
    """
    Class for sending mail
    """

    def __init__(self, mail_subject=None, mail_content=None, to=None, cc=None, bcc=None,
                 sender_alias=None, sender_email=None, sender_password=None, attchment_paths=None, mailserver=None,
                 mailserverport=25, auth_protocol='SMTP-AUTH', auth=True, is_file=False, file_object_list=None,
                 rcpt_options=None):
        """
        Function to initialize all the required parameters for sending mail

        :param mail_subject: Mail Subject
        :type mail_subject: str
        :param mail_content: Mail Body
        :type mail_content: str
        :param to: list of receiver mail ids in single string
        :type to: str
        :param cc: list of cc receiver mail ids in single string
        :type cc: str
        :param bcc: list of bcc receiver mail ids in single string
        :type bcc: str
        :param sender_alias: sender alias
        :type sender_alias: str
        :param sender_email: sender email id
        :type sender_email: str
        :param sender_password: sender password
        :type sender_password: str
        :param attchment_paths: attachment paths
        :type attchment_paths: str
        :param mailserver: smtp mail server
        :type mailserver:str
        :param rcpt_options: get status of delivered mail
        :type rcpt_options: list
        :param is_file: Flag to turn on attachments as file object
        :type is_file: bool
        :param file_object_list: File object Dict as {file_name: file_object}
        :type file_object_list: dict


        """
        self.attachment_flag = True
        self.status = False
        self._status_list = list()
        self.mail_subject = mail_subject
        self.mail_content = mail_content
        self.to_list = to
        self.cc_list = cc
        self.bcc_list = bcc
        self.sender_alias = sender_alias
        self.sender_email = sender_email
        self.sender_password = sender_password
        self.filepath = attchment_paths
        self.mailserver = mailserver
        self.mailserverport = mailserverport
        self.auth_protocol = auth_protocol
        self.auth = auth
        self.rcpt_options = rcpt_options
        self.is_file = is_file
        self.file_object_list = file_object_list
        self.publish_mail()
        self._status_list.append(self.status)

    def __getitem__(self, pos):
        return self._status_list[0]

    def publish_mail(self):
        """
        Function to publish mail
        :return: status of mail sent
        :rtype: dict
        """
        params_status = self.params_check()
        if params_status is True:
            self.status = self.mail_sender()
        else:
            self.status = params_status
        return self.status

    def params_check(self):
        """
        Function to check initail parameters provided by user
        :return: parameters validation status
        :rtype: dict
        """
        if self.mail_subject is None:
            self.mail_subject = ''
        else:
            if not isinstance(self.mail_subject, str):
                raise Exception('%s' % str({"Mail Subject": "InvalidDataType -- String Required"}))

        if self.mail_content is None:
            self.mail_content = ''
        else:
            if not isinstance(self.mail_content, str):
                raise Exception('%s' % str({"Mail Content": "InvalidDataType -- String Required"}))

        if self.to_list is None and self.cc_list is None and self.bcc_list is None:
            raise Exception('%s' % str({"Email Id": "NoReceiverEmaiIdFound"}))
        else:
            if self.to_list is None:
                self.to_list = ''
            else:
                if not isinstance(self.to_list, str):
                    raise Exception('%s' % str({"To": "InvalidDataType -- String Required"}))

            if self.cc_list is None:
                self.cc_list = ''
            else:
                if not isinstance(self.cc_list, str):
                    raise Exception('%s' % str({"Mail Cc": "InvalidDataType -- String Required"}))

            if self.bcc_list is None:
                self.bcc_list = ''
            else:
                if not isinstance(self.bcc_list, str):
                    raise Exception('%s' % str({"Mail Bcc": "InvalidDataType -- String Required"}))

        if self.auth:
            if self.sender_alias is None or self.sender_password is None:
                sender_cred = ''
                if self.sender_alias is None:
                    sender_cred += 'Alias '
                else:
                    if not isinstance(self.sender_alias, str):
                        raise Exception('%s' % str({"Sender Alias": "InvalidDataType -- String Required"}))

                if self.sender_password is None:
                    sender_cred += 'Password'
                else:
                    if not isinstance(self.sender_password, str):
                        raise Exception('%s' % str({"Sender Password": "InvalidDataType -- String Required"}))

                raise Exception('%s' % str({"Sender Credentials": "NotFoundSender --> %s" % str(sender_cred)}))

        if self.sender_email is None:
            raise Exception('%s' % str({"Sender Credentials": "NotFoundSender --> %s" % str('SenderEmail')}))
        else:
            if not isinstance(self.sender_email, str):
                raise Exception('%s' % str({"Sender Email": "InvalidDataType -- String Required"}))

        if self.filepath is None and self.is_file is False:
            self.attachment_flag = False
        else:
            if self.filepath:
                for filepath in self.filepath:
                    if not os.path.exists(filepath):
                        raise Exception('%s' % str({"Attachment": 'PathNotExist : %s' % str(filepath)}))

        if self.mailserver is None:
            raise Exception('%s' % str({"Mail Server": "NoMailServerFound"}))
        else:
            if not isinstance(self.mailserver, str):
                raise Exception('%s' % str({"Smtp Server": "InvalidDataType -- String Required"}))
        if self.rcpt_options is None:
            self.rcpt_options = ()

        if self.mailserverport is None:
            raise Exception('%s' % str({"Mail Server Port": "NoMailServerPortFound"}))
        else:
            if not isinstance(self.mailserverport, int):
                raise Exception('%s' % str({"Smtp Server Port": "InvalidDataType -- Int Required"}))

        if self.rcpt_options is None:
            self.rcpt_options = ()

        return True

    def assign_files(self, file_object='', msg=''):
        """
        Function to load attachment file from given loaction
        :param file_object: path of attachment
        :type file_object: dict
        :param msg: mail object
        :type msg: object
        :return: attachment object
        :rtype: object
        """
        try:
            file_names = list(file_object.keys())
            for file_name in file_names:
                ctype, encoding = mimetypes.guess_type(file_name)
                if ctype is None or encoding is not None:
                    ctype = "application/octet-stream"

                maintype, subtype = ctype.split("/", 1)
                #
                if maintype == "text":
                    attachment = MIMEText(self.file_object_list[file_name].decode(), _subtype=subtype)
                elif maintype == "image":
                    attachment = MIMEImage(self.file_object_list[file_name], _subtype=subtype)
                elif maintype == "audio":
                    attachment = MIMEAudio(self.file_object_list[file_name], _subtype=subtype)
                else:
                    attachment = MIMEBase(maintype, subtype)
                    attachment.set_payload(file_object[file_name])
                    encoders.encode_base64(attachment)
                attachment.add_header("Content-Disposition", "attachment", filename=file_name)
                msg.attach(attachment)
            return attachment, True
        except Exception as excp:
            raise Exception('%s' % str({"AttachmentReadError": excp}))

    def assign_attachment(self, filepaths='', msg=''):
        """
        Function to load attachment file from given loaction
        :param filepaths: path of attachment
        :type filepaths: str
        :param msg: mail object
        :type msg: object
        :return: attachment object
        :rtype: object
        """
        try:
            for filepath in filepaths:
                ctype, encoding = mimetypes.guess_type(filepath)
                if ctype is None or encoding is not None:
                    ctype = "application/octet-stream"

                maintype, subtype = ctype.split("/", 1)

                if maintype == "text":
                    fp = open(filepath)
                    attachment = MIMEText(fp.read(), _subtype=subtype)
                    fp.close()
                elif maintype == "image":
                    fp = open(filepath, "rb")
                    attachment = MIMEImage(fp.read(), _subtype=subtype)
                    fp.close()
                elif maintype == "audio":
                    fp = open(filepath, "rb")
                    attachment = MIMEAudio(fp.read(), _subtype=subtype)
                    fp.close()
                else:
                    fp = open(filepath, "rb")
                    attachment = MIMEBase(maintype, subtype)
                    attachment.set_payload(fp.read())
                    fp.close()
                    encoders.encode_base64(attachment)
                attachment.add_header("Content-Disposition", "attachment", filename=os.path.split(filepath)[-1])
                msg.attach(attachment)
            return attachment, True
        except Exception as excp:
            raise Exception('%s' % str({"AttachmentReadError": excp}))

    def mail_sender(self):
        """
        Function to connect to login smtp server and sent mail
        :return: status of mail sent

        """
        msg = MIMEMultipart()
        msg['From'] = self.sender_email
        msg['To'] = self.to_list
        msg['Subject'] = self.mail_subject
        msg['CC'] = self.cc_list
        msg['BCC'] = self.bcc_list
        email_body = str(self.mail_content)
        try:
            msg.attach(MIMEText(email_body, 'html'))

            if self.attachment_flag is True:
                if not self.is_file:
                    attachment, attach_status = self.assign_attachment(self.filepath, msg)
                else:
                    attachment, attach_status = self.assign_files(self.file_object_list, msg)
                if attach_status is False:
                    return attachment

            email_content = msg.as_string()

            if self.auth_protocol == 'START-TLS':
                server = smtplib.SMTP(self.mailserver, self.mailserverport)
                server.connect(self.mailserver, self.mailserverport)
                server.ehlo()
                server.starttls()
                server.ehlo()
            elif self.auth_protocol == 'SMTP-AUTH':
                server = smtplib.SMTP(self.mailserver, self.mailserverport)

            if self.auth:
                server.login(self.sender_alias, self.sender_password)

            # Prepare receipients
            recipients = msg["To"].split(",")
            if self.cc_list:
                recipients = recipients + msg["CC"].split(",")
            if self.bcc_list:
                recipients = recipients + msg["BCC"].split(",")
            smtp_response = server.sendmail(msg['From'], recipients, email_content, rcpt_options=self.rcpt_options)
            server.quit()
            return {"To": self.to_list, "Cc": self.cc_list, "Bcc": self.bcc_list, "Subject": self.mail_subject,
                    'smtp_response': smtp_response}
        except Exception as excp:
            raise Exception('%s' % str({"MailSendingError": excp}))


def help():
    """
    Function to provide help in mail package
    :return: None
    :rtype: None
    """
    help = """

STEPS TO SEND MAIL :

from email_amns import PublishMail

mail_status=PublishMail(mail_subject='THIS IS MAIL PACKAGE TEST ', mail_content='THIS IS MAIL PACKAGETEST ',

        to='abc1@mail.co.in,abc2@mail.co.in,',cc='abc3@mail.co.in,abc4@mail.co.in,',

        bcc='abc5@mail.co.in,abc6@mail.co.in,',sender_alias='abc',sender_email='abc7@mail.co.in',

        sender_password='abc@123', attchment_paths=['E:/TUTORIALs/filename1.pdf','E:/TUTORIALs/filename2.pdf'],
        mailserver='email.smtp.com', rcpt_options=['NOTIFY=SUCCESS,DELAY,FAILURE'])

print(mail_status[0])



About Parameters :

mail_subject ={NOT REQUIRED} subject of your mail

mail_content ={NOT REQUIRED} mail body (may content html syntax)

to ={REQUIRED} list of mail ids of receiver (@eg. 'abc1@mail.co.in,abc2@mail.co.in,')

cc ={NOT REQUIRED} list of mail ids in cc of receiver (@eg. 'abc3@mail.co.in,abc4@mail.co.in,')

bcc ={NOT REQUIRED} list of mail ids in bcc of receiver (@eg. 'abc5@mail.co.in,abc6@mail.co.in,')

sender_alias ={REQUIRED} Login alias of sender (@eg. sdds)

sender_email ={REQUIRED} Login email id of sender (@eg. sdds@mail.co.in)

sender_password ={REQUIRED} Login password of sender (@eg. ******)

attchment_paths ={NOT REQUIRED} list of path of attachment files

mailserver ={REQUIRED} mail server from which mail will be send (@eg. email.stmp.com)

rcpt_options ={NOT REQUIRED} get status of delivered mail

is_file = {NOT REQUIRED} flag if file object is directly passed as arguments

file_object_list = {NOT REQUIRED} used to send file objects as a dict {'file_name': file_object}

"""

print(help)
