# pylint: disable = E0401,C0301,C0111,R0903,R0201
"""
User model serializer
"""
from django.contrib.auth.models import User
from rest_framework.serializers import ModelSerializer
# from api.models import CustomUser


class UserSerializer(ModelSerializer):

    class Meta:
        model = User
        fields = '__all__'
        # exclude = ('password',
        #            "is_staff",
        #            "first_name",
        #            "last_name",
        #            "date_joined")


class UserSuggestionSerializer(ModelSerializer):
    """
    Serializer for drop down
    """
    class Meta:
        model = User
        fields = ['id', 'username']
