# pylint: disable = E0401,C0301,C0111,R0903,R0201
"""
Group model serializer
"""

from django.contrib.auth.models import Group
from rest_framework.serializers import ModelSerializer

from rbac.serializers.Permission import PermissionSerializer


class GroupSerializer(ModelSerializer):
    permissions = PermissionSerializer(many=True)

    class Meta:
        model = Group
        fields = "__all__"


class GroupSuggestionSerializer(ModelSerializer):
    """
    Serializer for drop down
    """

    class Meta:
        model = Group
        fields = ['id', 'name']
