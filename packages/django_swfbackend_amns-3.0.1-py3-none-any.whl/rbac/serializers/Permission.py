# pylint: disable = E0401,C0301,C0111,R0903,R0201
"""
Permission model serializer
"""

from django.contrib.auth.models import Permission
from rest_framework.serializers import ModelSerializer

from rbac.serializers.ContentType import ContentTypeSerializer


class PermissionSerializer(ModelSerializer):
    content_type = ContentTypeSerializer()

    class Meta:
        model = Permission
        fields = "__all__"
