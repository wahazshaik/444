# pylint: disable = E0401,C0301,C0111,R0903,R0201
"""
Url configuration
"""
from django.urls import path

from rbac.views import GenericView, Suggest

urlpatterns = [
    path('meta', GenericView.as_view(), name='User'),
    path('Users', GenericView.as_view(), name="User"),
    path('Users/<int:id>', GenericView.as_view(), name="User"),
    path('Users/<str:group>', GenericView.as_view(), name="User"),
    path('Suggest/<str:type>', Suggest.as_view(), name="Suggest"),
    path('Groups', GenericView.as_view(), name="Group"),
    path('Groups/<int:id>', GenericView.as_view(), name="Group"),
    path('Groups/<str:user>', GenericView.as_view(), name="Group"),
    path('Permissions', GenericView.as_view(), name="Permission"),
    path('Permissions/<int:id>', GenericView.as_view(), name="Permission"),
    path('Permissions/<str:model>', GenericView.as_view(), name="Permission"),
]
