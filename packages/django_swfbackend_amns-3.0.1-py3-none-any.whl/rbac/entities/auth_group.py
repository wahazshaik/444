# pylint: disable = E0401,C0301,C0111,R0903,R0201
"""
Proxy model
"""
from django.contrib.auth.models import Group, User
from rest_framework import status

from rbac.helper import add_users_to_group, remove_users_in_group
from rbac.manager import AuthGroupManager
# from api.models import CustomUser
from rbac.serializers.Group import GroupSerializer, GroupSuggestionSerializer


class AuthGroup(Group):
    """
    Proxy Model for Group
    """

    objects = AuthGroupManager()

    @staticmethod
    def __serialize_groups_many(groups):

        """
        Purpose: Serialize the groups with flag many=True
        :param groups: Groups to be serialized
        :type groups: QuerySet
        :return: Serialized data and status
        :rtype: str, status
        """

        if groups is not None:
            serializer = GroupSerializer(groups, many=True)
            return serializer.data, status.HTTP_200_OK
        else:
            return None, status.HTTP_204_NO_CONTENT

    @staticmethod
    def get_groups_by_id(request, kwargs):

        """
        Purpose: To get group by id
        :param request: Network Request object
        :type request: Request Object
        :param kwargs: Network Request object keywords arguments
        :type kwargs: List
        :return: Serialized Group with status flag
        :rtype: str, status
        """

        groups = AuthGroup.objects.get_by_id(kwargs['id'])
        if groups is not None:
            serializer = GroupSerializer(groups)
            return serializer.data, status.HTTP_200_OK
        else:
            return None, status.HTTP_204_NO_CONTENT

    @staticmethod
    def get_groups_by_user(request, kwargs):
        """
        Purpose: To get groups by username
        :param request: Network Request object
        :type request: Request Object
        :param kwargs: Network Request object keywords arguments
        :type kwargs: List
        :return: Serialized Group with status flag
        :rtype: str, status
        """

        user = User.objects.get(username=kwargs['user'])
        groups = user.groups.all()
        return AuthGroup.__serialize_groups_many(groups)

    @staticmethod
    def get_all_groups(request, kwargs):
        """
        Purpose: To get all groups
        :param request: Network Request object
        :type request: Request Object
        :param kwargs: Network Request object keywords arguments
        :type kwargs: List
        :return: Serialized Group with status flag
        :rtype: str, status
        """

        groups = AuthGroup.objects.get_all()
        return AuthGroup.__serialize_groups_many(groups)

    @staticmethod
    def post(request):
        """
        Purpose: To add the group to DB
        :param request: Network Request object
        :type request: Request Object
        :return: Serialized New Group with status flag
        :rtype: str, status
        """

        group = AuthGroup.objects.create(name=request['groupName'])
        add_users_to_group(request['users'], group)

        serializer = GroupSerializer(group)

        return serializer.data, status.HTTP_201_CREATED

    @staticmethod
    def patch(request, edit_id):
        """
        Purpose: To edit the group in DB
        :param request: Network Request object
        :type request: Request Object
        :param edit_id: Id of the group to be edited
        :type edit_id: int
        :return: Serialized Edited Group with status flag
        :rtype: str, status
        """

        group = AuthGroup.objects.get_by_id(edit_id)
        remove_users_in_group(group)
        add_users_to_group(request['users'], group)
        group.save()

        serializer = GroupSerializer(group)

        return serializer.data, status.HTTP_200_OK

    @staticmethod
    def remove(delete_id):
        """
        Purpose: To delete the group from DB
        :param delete_id: Id of the group to be deleted
        :type delete_id: int
        :return: Serialized remaining groups with status
        :rtype: str, status
        """

        AuthGroup.objects.get_by_id(delete_id).delete()
        return AuthGroup.get_all_groups(None, None)

    @staticmethod
    def suggest_groups(request):
        """
        Purpose: To filter 10 matching groups based on query for drop down suggestion
        :param request: Network Request object
        :type request: Request Object
        :return: Serialized filtered groups with status
        :rtype: str, status
        """

        groups = AuthGroup.objects.get_by_filter(name__icontains=request.GET['query'])[:10]

        if groups is not None:
            serializer = GroupSuggestionSerializer(groups, many=True)
            return serializer.data, status.HTTP_200_OK
        else:
            return None, status.HTTP_204_NO_CONTENT

    class Meta:
        """
            Purpose: proxy->True to override the main functionality of existing WorkflowStateModel
        """

        proxy = True
