# pylint: disable = E0401,C0301,C0111,R0903,R0201
"""
Proxy model
"""

from django.apps import apps
from django.contrib.auth.models import Permission
from django.contrib.contenttypes.models import ContentType
from rest_framework import status

from rbac.constants import APP_NAME
from rbac.entities.auth_group import AuthGroup
from rbac.entities.auth_user import AuthUser
from rbac.helper import remove_permissions_from_user, add_permissions_to_user, \
    remove_permissions_from_group, add_permissions_to_group
from rbac.manager import AuthPermissionManager
from rbac.serializers.Permission import PermissionSerializer


class AuthPermission(Permission):
    """
    Proxy Model for Permission
    """

    objects = AuthPermissionManager()

    @staticmethod
    def get_permissions_by_group(request, kwargs):
        """
        Purpose: To get permissions by group
        :param request: Network Request object
        :type request: Request Object
        :param kwargs: Network Request object keywords arguments
        :type kwargs: List
        :return: Serialized Permission with status flag
        :rtype: str, status
        """

        content_type = ContentType.objects. \
            get_for_model(model=apps.get_model(APP_NAME, kwargs['model']))

        permissions = AuthGroup.objects.get_by_filter(name=request.GET['group'])[0] \
            .permissions.filter(content_type=content_type)
        return AuthPermission.__serialize_permissions_many(permissions)

    @staticmethod
    def get_permissions_by_user(request, kwargs):
        """
        Purpose: To get permissions by user
        :param request: Network Request object
        :type request: Request Object
        :param kwargs: Network Request object keywords arguments
        :type kwargs: List
        :return: Serialized Permission with status flag
        :rtype: str, status
        """

        content_type = ContentType.objects.get_for_model(model=apps.get_model(APP_NAME, kwargs['model']))
        permissions = AuthPermission.objects.get_by_filter(content_type=content_type,
                                                           user__username=request.GET['user'])
        return AuthPermission.__serialize_permissions_many(permissions)

    @staticmethod
    def get_permissions_by_model(request, kwargs):
        """
        Purpose: To get permissions by model
        :param request: Network Request object
        :type request: Request Object
        :param kwargs: Network Request object keywords arguments
        :type kwargs: List
        :return: Serialized Permission with status flag
        :rtype: str, status
        """
        content_type = ContentType.objects.get_for_model(model=apps.get_model(APP_NAME, kwargs['model']))
        permissions = AuthPermission.objects.get_by_filter(content_type=content_type)
        return AuthPermission.__serialize_permissions_many(permissions)

    @staticmethod
    def get_all_permissions(request, kwargs):
        """
        Purpose: To get all permissions
        :param request: Network Request object
        :type request: Request Object
        :param kwargs: Network Request object keywords arguments
        :type kwargs: List
        :return: Serialized Permission with status flag
        :rtype: str, status
        """

        permissions = AuthPermission.objects.get_all()
        return AuthPermission.__serialize_permissions_many(permissions)

    @staticmethod
    def get_permissions_by_id(request, kwargs):
        """
        Purpose: To get permission by id
        :param request: Network Request object
        :type request: Request Object
        :param kwargs: Network Request object keywords arguments
        :type kwargs: List
        :return: Serialized Permission with status flag
        :rtype: str, status
        """

        permissions = AuthPermission.objects.get_by_id(kwargs['id'])
        if permissions is not None:
            serializer = PermissionSerializer(permissions)
            return serializer.data, status.HTTP_200_OK
        else:
            return None, status.HTTP_204_NO_CONTENT

    @staticmethod
    def post(request):
        """
        Purpose: To add permission by DB or to assign permissions to user/group
        :param request: Network Request object
        :type request: Request Object
        :return: Serialized New Permission with status flag
        :rtype: str, status
        """

        # Checking type for assigning permissions
        if 'type' in request:
            if request['type'] == 'User':
                return AuthPermission.__set_permissions_to_user(request)
            else:
                return AuthPermission.__set_permissions_to_group(request)

        # Permission is to be created not assigned
        else:
            content_type = ContentType.objects \
                .get_for_model(model=apps.get_model(APP_NAME, request['model']))
            permission = AuthPermission.objects.create(name=request['name'],
                                                       content_type=content_type,
                                                       codename=request['codename'])
            serializer = PermissionSerializer(permission)
            return serializer.data, status.HTTP_201_CREATED

    @staticmethod
    def patch(request, edit_id):
        """
        Purpose: To edit permission in DB
        :param request: Network Request object
        :type request: Request Object
        :param edit_id: Id of the permission to be edited
        :type edit_id: int
        :return: Serialized Edited Permission with status flag
        :rtype: str, status
        """

        permission = AuthPermission.objects.get_by_id(edit_id)
        permission = AuthPermission.__patch_data_changes(request, permission)
        permission.save()

        serializer = PermissionSerializer(permission)
        return serializer.data, status.HTTP_200_OK

    @staticmethod
    def remove(delete_id):
        """
        Purpose: To delete permission from DB
        :param delete_id: Id of the permission to be deleted
        :type delete_id: int
        :return: Serialized remaining permissions with status
        :rtype: str, status
        """

        Permission.objects.filter(id=delete_id).delete()
        return AuthPermission.get_all_permissions(None, None)

    @staticmethod
    def __set_permissions_to_user(request):
        """
        Purpose: To remove old permissions & assign new permissions to user
        :param request: Network Request object
        :type request: Request Object
        :return: None with status
        :rtype: None, status
        """

        selected_user = AuthUser.objects.get_by_filter(username=request['item'])[0]
        remove_permissions_from_user(selected_user, request['model'])
        add_permissions_to_user(selected_user, request['permissions'])

        return AuthPermission.get_all_permissions(None, None), status.HTTP_200_OK

    @staticmethod
    def __set_permissions_to_group(request):
        """
        Purpose: To remove old permissions & assign new permissions to group
        :param request: Network Request object
        :type request: Request Object
        :return: None with status
        :rtype: None, status
        """

        selected_group = AuthGroup.objects.get_by_filter(name=request['item'])[0]
        remove_permissions_from_group(selected_group, request['model'])
        add_permissions_to_group(selected_group, request['permissions'])

        return AuthPermission.get_all_permissions(None, None), status.HTTP_200_OK

    @staticmethod
    def __serialize_permissions_many(permissions):
        """
        Purpose: Serialize the permissions with flag many=True
        :param permissions: Serialize Permissions
        :type permissions: QuerySet Object
        :return: Serialized data and status
        :rtype: str, status
        """

        if permissions is not None:
            serializer = PermissionSerializer(permissions, many=True)
            return serializer.data, status.HTTP_200_OK
        else:
            return None, status.HTTP_204_NO_CONTENT

    @staticmethod
    def __patch_data_changes(request, permission):
        """
        Purpose: To patch the data changes
        :param request: Network Request object
        :type request: Request Object
        :param permission: Model to edit
        :type permission: Permission object
        :return: Modified permission object
        :rtype: Permission Object
        """

        if 'model' in request:
            model = apps.get_model(APP_NAME, request['model'])
            content_type = ContentType.objects.get_for_model(model=model)
            permission.content_type = content_type
        if 'codename' in request:
            permission.codename = request['codename']
        if 'name' in request:
            permission.codename = request['codename']

        return permission

    class Meta:
        """
            Purpose: proxy->True to override the main functionality of existing WorkflowStateModel
        """
        proxy = True
