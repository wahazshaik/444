"""
 App Constants
"""
from django.conf import settings

MASTERS_APP_RBAC = settings.__dict__['_wrapped'].__dict__['MASTERS_APP_RBAC']

PERMISSIONS_GET_FUNCTIONS = {
    'id': 'get_permissions_by_id',
    'user': 'get_permissions_by_user',
    'group': 'get_permissions_by_group',
    'model': 'get_permissions_by_model',
    'all': 'get_all_permissions'
}

GROUPS_GET_FUNCTIONS = {
    'id': 'get_groups_by_id',
    'user': 'get_groups_by_user',
    'all': 'get_all_groups'
}

USERS_GET_FUNCTIONS = {
    'id': 'get_users_by_id',
    'group': 'get_users_by_group',
    'all': 'get_all_users'
}

PERMISSION_MODEL_NAME = 'Permission'
GROUP_MODEL_NAME = 'Group'
USER_MODEL_NAME = 'User'
BASE_MODEL_NAME = 'Models'
APP_NAME = MASTERS_APP_RBAC
