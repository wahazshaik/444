# pylint: disable = E0401,C0301,C0111,R0903,R0201
"""
Model manager which will do something analogous to a DAO.
"""

from django.db.models.manager import Manager



class BaseManager(Manager):
    """
        Purpose: to be used by model specific managers
    """

    def get_all(self):
        """
        Get all Data
        """
        return super(BaseManager, self).all()

    def get_by_id(self, pk):
        """
        Purpose: Get data by id
        :param pk: id
        :type pk: int
        """
        return super(BaseManager, self).get(id=pk)

    def get_by_filter(self, **filters):
        """
        Purpose: Get data by filter
        :param filters: filter
        :type filters: List
        """
        return super(BaseManager, self).filter(**filters)


class AuthUserManager(BaseManager):

    """
        Purpose: create/get/delete/save for AuthUser Model
    """


class AuthGroupManager(BaseManager):
    """
        Purpose: create/get/delete/save for AuthGroup Model
    """


class AuthPermissionManager(BaseManager):
    """
        Purpose: create/get/delete/save for AuthGroup Model
    """
