from django.contrib.auth import authenticate
# Create your tests here.
from django.contrib.auth.models import User, Group, Permission
from django.contrib.contenttypes.models import ContentType
from django.test import TestCase
from django.urls import reverse
from rest_framework import status
from rest_framework.authtoken.models import Token

from VendorMaster.models import Company


class PostTests(TestCase):

    def setUp(self):
        # Creating User
        self.user = User.objects.create_user("rushu", password="uhsur")

        # Creating Group
        self.test_grp, created = Group.objects.get_or_create(name='super')
        self.test_grp.user_set.add(self.user)

        # Creating Permissions
        self.content_type = ContentType.objects.get_for_model(Company)
        self.permission, created = Permission.objects.get_or_create(codename='view_company',
                                                                    content_type=self.content_type)

        # Authenticating User
        self.user = authenticate(username="rushu", password="uhsur")
        self.token = Token.objects.create(user=self.user)

    def test_GET_users(self):
        """
        Purpose: To get all users using API call
        """

        url = reverse('User')

        print("Request: " + url)
        response = self.client.get(url, format="json", HTTP_AUTHORIZATION='Token ' + str(self.token))
        print("Response data length: ", len(response.data))

        self.assertEqual(response.status_code, status.HTTP_200_OK)

    def test_GET_users_by_id(self):
        """
        Purpose: To get all users by Id using API call
        """

        url = reverse('User', kwargs={'id': self.user.id})

        print("Request data length: " + url)
        response = self.client.get(url, format="json", HTTP_AUTHORIZATION='Token ' + str(self.token))
        print("Response: ", len(response.data))

        self.assertEqual(response.status_code, status.HTTP_200_OK)

    def test_GET_users_by_group(self):
        """
        Purpose: To get all users by group name using API call
        """

        url = reverse('User', kwargs={'group': self.test_grp.name})

        print("Request data length: " + url)
        response = self.client.get(url, format="json", HTTP_AUTHORIZATION='Token ' + str(self.token))
        print("Response: ", len(response.data))

        self.assertEqual(response.status_code, status.HTTP_200_OK)

    def test_POST_users_without_groups(self):
        """
        Purpose: To post user without any group using API call
        """

        url = reverse('User')
        # User Json expected in request payload
        request_data = '{"userName": "rushabh111", "userPassword": "testing","groups":[]}'

        print("Request: " + url)
        response = self.client.post(url, format='json', content_type='application/json;charset=UTF-8',
                                    data=request_data,
                                    HTTP_AUTHORIZATION='Token ' + str(self.token))
        print("Response data length: ", len(response.data))

        self.assertEqual(response.status_code, status.HTTP_201_CREATED)

    def test_POST_users_with_groups(self):
        """
        Purpose: To post user with a group using API call
        """

        url = reverse('User')
        # User Json expected in request payload
        request_data = '{"userName": "rushabh101", "userPassword": "testing", "groups": [' + str(
            self.test_grp.id) + ']}'

        print("Request: " + url)
        response = self.client.post(url, content_type='application/json;charset=UTF-8',
                                    format='json', data=request_data,
                                    HTTP_AUTHORIZATION='Token ' + str(self.token))
        print("Response data length: ", len(response.data))

        self.assertEqual(response.status_code, status.HTTP_201_CREATED)

    def test_PATCH_users_without_groups(self):
        """
        Purpose: To patch user without group using API call
        """

        url = reverse('User', kwargs={'id': self.user.id})
        # User Json expected in request payload
        request_data = '{"userName":"rushabh101","userPassword":"testing","groups":[]}'

        print("Request: " + url)
        response = self.client.patch(url, format='json', content_type='application/json;charset=UTF-8',
                                     data=request_data,
                                     HTTP_AUTHORIZATION='Token ' + str(self.token))
        print("Response data length: ", len(response.data))

        self.assertEqual(response.status_code, status.HTTP_200_OK)

    def test_PATCH_users_with_groups(self):
        """
        Purpose: To patch user with a group using API call
        """

        url = reverse('User', kwargs={'id': self.user.id})
        # User Json expected in request payload
        request_data = '{"userName":"rushabh101","userPassword":"testing", "groups": [' + str(self.test_grp.id) + ']}'

        print("Request: " + url)
        response = self.client.patch(url, format='json', content_type='application/json;charset=UTF-8',
                                     data=request_data,
                                     HTTP_AUTHORIZATION='Token ' + str(self.token))
        print("Response data length: ", len(response.data))

        self.assertEqual(response.status_code, status.HTTP_200_OK)

    def test_DELETE_users(self):
        """
        Purpose: To delete user
        """

        url = reverse('User', kwargs={'id': self.user.id})

        print("Request: " + url)
        response = self.client.delete(url, format='json', content_type='application/json;charset=UTF-8',
                                      HTTP_AUTHORIZATION='Token ' + str(self.token))
        print("Response data length: ", len(response.data))

        self.assertEqual(response.status_code, status.HTTP_200_OK)

    def test_GET_users_suggestions(self):
        """
        Purpose: To get user suggestions based on query
        """

        url = reverse('Suggest', kwargs={'type': 'User'})

        print("Request data length: " + url)
        response = self.client.get(url, data={'query': 'a'}, format="json",
                                   HTTP_AUTHORIZATION='Token ' + str(self.token))
        print("Response: ", len(response.data))

        self.assertEqual(response.status_code, status.HTTP_200_OK)

    def test_GET_groups(self):
        """
        Purpose: To get all groups using API call
        """

        url = reverse('Group')

        print("Request: " + url)
        response = self.client.get(url, format="json", HTTP_AUTHORIZATION='Token ' + str(self.token))
        print("Response data length: ", len(response.data))

        self.assertEqual(response.status_code, status.HTTP_200_OK)

    def test_GET_groups_by_id(self):
        """
        Purpose: To get all groups by Id using API call
        """

        url = reverse('Group', kwargs={'id': self.test_grp.id})

        print("Request data length: " + url)
        response = self.client.get(url, format="json", HTTP_AUTHORIZATION='Token ' + str(self.token))
        print("Response: ", len(response.data))

        self.assertEqual(response.status_code, status.HTTP_200_OK)

    def test_GET_groups_by_user(self):
        """
        Purpose: To get all groups by username using API call
        """

        url = reverse('Group', kwargs={'user': self.user.username})

        print("Request data length: " + url)
        response = self.client.get(url, format="json", HTTP_AUTHORIZATION='Token ' + str(self.token))
        print("Response: ", len(response.data))

        self.assertEqual(response.status_code, status.HTTP_200_OK)

    def test_POST_groups_without_users(self):
        """
        Purpose: To post group without any users using API call
        """

        url = reverse('Group')
        # Group Json expected in request payload
        request_data = '{"groupName":"Testing123","users":[]}'

        print("Request: " + url)
        response = self.client.post(url, format='json', content_type='application/json;charset=UTF-8',
                                    data=request_data,
                                    HTTP_AUTHORIZATION='Token ' + str(self.token))
        print("Response data length: ", len(response.data))

        self.assertEqual(response.status_code, status.HTTP_201_CREATED)

    def test_POST_groups_with_users(self):
        """
        Purpose: To post group with a users using API call
        """

        url = reverse('Group')
        # Group Json expected in request payload
        request_data = '{"groupName":"Testing123","users": [' + str(
            self.user.id) + ']}'

        print("Request: " + url)
        response = self.client.post(url, content_type='application/json;charset=UTF-8',
                                    format='json', data=request_data,
                                    HTTP_AUTHORIZATION='Token ' + str(self.token))
        print("Response data length: ", len(response.data))

        self.assertEqual(response.status_code, status.HTTP_201_CREATED)

    def test_PATCH_groups_without_users(self):
        """
        Purpose: To patch group without user using API call
        """

        url = reverse('Group', kwargs={'id': self.test_grp.id})
        # Group Json expected in request payload
        request_data = '{"groupName":"Testing123","users":[]}'

        print("Request: " + url)
        response = self.client.patch(url, format='json', content_type='application/json;charset=UTF-8',
                                     data=request_data,
                                     HTTP_AUTHORIZATION='Token ' + str(self.token))
        print("Response data length: ", len(response.data))

        self.assertEqual(response.status_code, status.HTTP_200_OK)

    def test_PATCH_groups_with_users(self):
        """
        Purpose: To patch group with a user using API call
        """

        url = reverse('Group', kwargs={'id': self.test_grp.id})
        # Group Json expected in request payload
        request_data = '{"groupName":"Testing123","users": [' + str(
            self.user.id) + ']}'

        print("Request: " + url)
        response = self.client.patch(url, content_type='application/json;charset=UTF-8',
                                     format='json', data=request_data,
                                     HTTP_AUTHORIZATION='Token ' + str(self.token))
        print("Response data length: ", len(response.data))

        self.assertEqual(response.status_code, status.HTTP_200_OK)

    def test_DELETE_groups(self):
        """
        Purpose: To delete group
        """

        url = reverse('Group', kwargs={'id': self.user.id})

        print("Request: " + url)
        response = self.client.delete(url, format='json', content_type='application/json;charset=UTF-8',
                                      HTTP_AUTHORIZATION='Token ' + str(self.token))
        print("Response data length: ", len(response.data))

        self.assertEqual(response.status_code, status.HTTP_200_OK)

    def test_GET_groups_suggestions(self):
        """
        Purpose: To get group suggestions based on query
        """

        url = reverse('Suggest', kwargs={'type': 'Group'})

        print("Request data length: " + url)
        response = self.client.get(url, data={'query': 'a'}, format="json",
                                   HTTP_AUTHORIZATION='Token ' + str(self.token))
        print("Response: ", len(response.data))

        self.assertEqual(response.status_code, status.HTTP_200_OK)

    def test_GET_permissions(self):
        """
        Purpose: To get all permissions using API call
        """

        url = reverse('Permission')

        print("Request data length: " + url)
        response = self.client.get(url, format="json", HTTP_AUTHORIZATION='Token ' + str(self.token))
        print("Response: ", len(response.data))

        self.assertEqual(response.status_code, status.HTTP_200_OK)

    def test_GET_permissions_by_id(self):
        """
        Purpose: To get all permissions by Id using API call
        """

        url = reverse('Permission', kwargs={'id': self.permission.id})

        print("Request data length: " + url)
        response = self.client.get(url, format="json", HTTP_AUTHORIZATION='Token ' + str(self.token))
        print("Response: ", len(response.data))

        self.assertEqual(response.status_code, status.HTTP_200_OK)

    def test_GET_permissions_by_model(self):
        """
        Purpose: To get all permissions by model name using API call
        """

        url = reverse('Permission', kwargs={'model': self.content_type.model})

        print("Request data length: " + url)
        response = self.client.get(url, format="json", HTTP_AUTHORIZATION='Token ' + str(self.token))
        print("Response: ", len(response.data))

        self.assertEqual(response.status_code, status.HTTP_200_OK)

    def test_GET_permissions_by_group(self):
        """
        Purpose: To get all permissions by group name using API call
        """

        url = reverse('Permission', kwargs={'model': self.content_type.model})

        print("Request data length: " + url)
        response = self.client.get(url, data={'group': self.test_grp.name}, format="json",
                                   HTTP_AUTHORIZATION='Token ' + str(self.token))
        print("Response: ", len(response.data))

        self.assertEqual(response.status_code, status.HTTP_200_OK)

    def test_GET_permissions_by_user(self):
        """
        Purpose: To get all permissions by user name using API call
        """

        url = reverse('Permission', kwargs={'model': self.content_type.model})
        print("Request data length: " + url)
        response = self.client.get(url, data={'user': self.user.username}, format="json",
                                   HTTP_AUTHORIZATION='Token ' + str(self.token))
        print("Response: ", len(response.data))
        self.assertEqual(response.status_code, status.HTTP_200_OK)

    def test_POST_permissions(self):
        """
        Purpose: To post permission using API call
        """

        url = reverse('Permission')
        # Permission Json expected in request payload
        request_data = '{"model":"Company","name":"Can view Company test","codename":"can_view_company_test"}'

        print("Request data length: " + url)
        response = self.client.post(url, content_type='application/json;charset=UTF-8',
                                    format='json', data=request_data,
                                    HTTP_AUTHORIZATION='Token ' + str(self.token))
        print("Response: ", len(response.data))
        self.assertEqual(response.status_code, status.HTTP_201_CREATED)

    def test_PATCH_permissions(self):
        """
        Purpose: To patch permission using API call
        """

        url = reverse('Permission', kwargs={'id': self.permission.id})
        # Permission Json expected in request payload
        request_data = '{"name":"Can view Company test","codename":"can_view_company_test"}'

        print("Request data length: " + url)
        response = self.client.patch(url, content_type='application/json;charset=UTF-8',
                                     format='json', data=request_data,
                                     HTTP_AUTHORIZATION='Token ' + str(self.token))
        print("Response: ", len(response.data))

        self.assertEqual(response.status_code, status.HTTP_200_OK)

    def test_DELETE_permissions(self):
        """
        Purpose: To delete permission
        """

        url = reverse('Permission', kwargs={'id': self.user.id})
        print("Request: " + url)
        response = self.client.delete(url, format='json', content_type='application/json;charset=UTF-8',
                                      HTTP_AUTHORIZATION='Token ' + str(self.token))
        print("Response data length: ", len(response.data))
        self.assertEqual(response.status_code, status.HTTP_200_OK)

    def test_GET_models_suggestions(self):
        """
        Purpose: To get model suggestions based on query
        """

        url = reverse('Suggest', kwargs={'type': 'Models'})
        print("Request data length: " + url)
        response = self.client.get(url, data={'query': 'a'}, format="json",
                                   HTTP_AUTHORIZATION='Token ' + str(self.token))
        print("Response: ", len(response.data))
        self.assertEqual(response.status_code, status.HTTP_200_OK)
