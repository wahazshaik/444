listview_const = {
    'DateTimeField': 'agDateColumnFilter',
    'IntegerField': 'agNumberColumnFilter'
}

appmeta_const = {
    'sectionName': 'MASTERS',
    'icon': 'fa fa-th-list'
}

appmeta2_const = {
    'sectionName': 'FORMS',
    'icon': 'fa fa-wpforms'
}
