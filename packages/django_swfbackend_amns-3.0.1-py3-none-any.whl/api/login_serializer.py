# pylint: disable = R0903,E0401,C0111,C0103

"""
Login serializer for the
incoming login ID and Password
"""
from django.apps import apps
from django.conf import settings
from django.contrib.auth import authenticate
from multipleldap_amns.MultiLDAPAuthenticator import MultipleLDAPAuthenticator
from multipleldap_amns.config import configuration
from rest_framework import serializers

from api.backend import custom_authenticate
from api.config_app import AUTHENTICATION_ERROR_MSG, USER_ROLES
from api.decorators import USER_LOGS
from django.contrib.auth.models import User

CHECK_USER_REGISTRATION = settings.__dict__['_wrapped'].__dict__['CHECK_USER_REGISTRATION']
USER_PROFILE_MODEL_DETAILS = settings.__dict__['_wrapped'].__dict__['USER_PROFILE_MODEL_DETAILS']

def GetUserData(res, username, password, type = None):
    data = {}
    if res[0]['status'] == AUTHENTICATION_ERROR_MSG["Success"]:
        if User.objects.filter(username__iexact=username).exists():
            user = User.objects.get(username__iexact=username)
            data['user'] = user
            data['status'] = AUTHENTICATION_ERROR_MSG["Success"]
            data['error'] = None
            data['type'] = type
            USER_LOGS.info(" User Authenticated -- {} ".format(str(username)))
            return data
        else:
            user = User.objects.create_user(username=username, is_staff=True)
            USER_LOGS.info(" New User Created Against Ldap User -- {}".format(str(username)))
            data['user'] = user
            data["status"] = AUTHENTICATION_ERROR_MSG["Success"]
            data["error"] = None
            data['type'] = type
            return data
    elif res[0]['status'] == AUTHENTICATION_ERROR_MSG["Failure"]:
        try:
            raise Exception
        except Exception:
            user = custom_authenticate(username=username, password=password)
            if user:
                data['status'] = AUTHENTICATION_ERROR_MSG["Success"]
                data["user"] = user
                data["error"] = None
                data['type'] = type
                return data
            else:
                data["status"] = AUTHENTICATION_ERROR_MSG["Failure"]
                data["error"] = AUTHENTICATION_ERROR_MSG["Invalid Credentials"]
                data['user'] = None
                data['type'] = type
                return data

        # data["status"] = AUTHENTICATION_ERROR_MSG["Failure"]
        # data["error"] = AUTHENTICATION_ERROR_MSG["Invalid Credentials"]
        # data['user'] = None
        # data['type'] = type
        # USER_LOGS.info(" Authentication Error for -- {}".format(str(username)))
        # USER_LOGS.debug(" Invalid Credentials for -- {}".format(str(username)))
        # return data


class LoginSerializer(serializers.Serializer):
    """
    Login Serializer for Username and Password
    provided with POST in JSON
    """
    username = serializers.CharField()
    password = serializers.CharField(write_only=True)
    # userType = serializers.CharField()

    def validate(self, data):
        if data.get("username") and data.get("password"):
            username = data.get("username").lower()
            password = data.get("password")
            # type = data.get("userType")
            if CHECK_USER_REGISTRATION:
                data = {}
                user_profile_model = apps.get_model(USER_PROFILE_MODEL_DETAILS['app'], USER_PROFILE_MODEL_DETAILS['model'])
                kwargs = {
                    f'{USER_PROFILE_MODEL_DETAILS["search_on_field"]}' : username
                }
                if not user_profile_model.objects.filter(**kwargs).exists():
                    data['user'] = None
                    data["status"] = AUTHENTICATION_ERROR_MSG["Failure"]
                    data['error'] = AUTHENTICATION_ERROR_MSG["Not Registered"]
                    return data

            configuration()
            authenticator = MultipleLDAPAuthenticator()
            res = authenticator.authenticate(username, password)
            return GetUserData(res, username,  password)
        else:
            message = AUTHENTICATION_ERROR_MSG["error"]
            return message


