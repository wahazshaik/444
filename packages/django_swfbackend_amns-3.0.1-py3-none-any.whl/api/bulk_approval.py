from django.db import transaction
from rest_framework import status
from rest_framework.response import Response

from api.utils import retrieve_correct_app
from workflow.services import approval_workflow

from workflow.services import WORKFLOW_LOGS


class bulkApprovalService:
    def bulk_approve(self, request, app, model, reject):
        app, model_obj = retrieve_correct_app(model)
        req_list = request.data
        failed_objects = []
        success_objects = []
        with transaction.atomic():
            for filter_pk in req_list:
                try:
                    req_obj = model_obj.objects.get(**filter_pk)
                    request_status, workflow_completed = approval_workflow(app=app.lower(), model=model.lower(),
                                                                           pk=req_obj.pk, action="Reject" if reject else "Approve",
                                                                           remarks="Bulk Rejected" if reject else "Bulk Approval",
                                                                           request=request,
                                                                           requesting_approvers=None)
                    req_obj.status = request_status
                    req_obj.is_approved = workflow_completed
                    req_obj.save()
                    success_objects.append(filter_pk)
                except Exception as e:
                    WORKFLOW_LOGS.debug(f'Bulk Approval Exception Raised for -- {filter_pk}')
                    WORKFLOW_LOGS.exception(e)
                    failed_objects.append(filter_pk)
                    continue

        return Response({"msg": "Bulk Approval Status",
                         'failed_data': failed_objects,
                         'success_data': success_objects}, status=status.HTTP_200_OK)






