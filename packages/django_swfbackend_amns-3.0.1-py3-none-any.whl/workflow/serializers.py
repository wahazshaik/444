# pylint: disable = E0401,C0301,C0111,R0903,R0201
"""
DRF Serializers
"""
import json

from rest_framework import serializers
from rest_framework.serializers import ModelSerializer

from workflow.models import WorkflowTransitionsMaster, WorkflowTransactions


class WorkflowTransitionSerializer(ModelSerializer):
    action_group = serializers.SerializerMethodField()

    def get_action_group(self, object):
        return json.loads(object.action_group)

    class Meta:
        model = WorkflowTransitionsMaster
        fields = "__all__"


class WorkflowTransactionSerializer(ModelSerializer):
    class Meta:
        model = WorkflowTransactions
        fields = "__all__"
