from api.logger_directory import workflow_logger

WORKFLOW_LOGS = workflow_logger()
