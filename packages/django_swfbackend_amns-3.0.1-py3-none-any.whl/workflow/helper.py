from workflow.constants import ACTION_VALIDATOR
from workflow.entities import WorkflowAction


def validate_action_of_workflow(transaction):
    registered_action = WorkflowAction.objects.filter(action_type=transaction["action"])
    print(registered_action)
    if registered_action.exists():
        if registered_action.first().is_approval():
            return ACTION_VALIDATOR["approval"]
        elif registered_action.first().is_init():
            return ACTION_VALIDATOR["init"]
        else:
            return ACTION_VALIDATOR["rejection"]
    else:
        return ACTION_VALIDATOR["invalid"]
