import traceback

from django.db.models.signals import post_save
from django.dispatch import receiver

from workflow.logger import WORKFLOW_LOGS
from workflow.entities import generate_links_for_groups
from workflow.entities import WorkflowLog


@receiver(post_save, sender=WorkflowLog)
def workflowlog_postsave(sender, instance, **kwargs):

    if kwargs.get('created', True):
        WORKFLOW_LOGS.debug("Postsave on Workflow log {} has been triggered".format(instance.pk))
        try:
            generate_links_for_groups(instance)
        except Exception as exc:
            WORKFLOW_LOGS.exception(traceback.format_exc())