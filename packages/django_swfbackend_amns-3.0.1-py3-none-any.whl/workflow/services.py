"""
Service Classes for a given module for each entities
"""
import json
import traceback

from api.utils import retrieve_correct_app
from django.apps import apps
from django.conf import settings
from django.db import transaction
from django.db.models import Q
from django.utils.module_loading import import_string
from rest_framework import status
from rest_framework.authtoken.models import Token
from rest_framework.response import Response

from api.logger_directory import workflow_logger
from workflow.constants import ACTION_VALIDATOR, WORKFLOW_STATUS
from workflow.entities import WorkflowTransitions, WorkflowLog, ApprovalLinkProxy
from workflow.exceptions import ActionAlreadyTakenException, NoMatchingTransitionFoundException, \
    RejectionDeniedException, InvalidActionException, NextApproverNotFoundException, NextTransitionNotFoundException, \
    ModelNotRegisteredWithWorkflowException, MatchingApproverGroupNotFoundException
from workflow.helper import validate_action_of_workflow
from workflow.inter_parallel_services import try_get_inter_next_approver, try_get_dynamic_current_obj_state
from workflow.models import WorkflowTransactions, ApprovalLinkSent
from workflow.strength_validators import check_allocated_strength_validity

from workflow.exceptions import EditThresholdReachedException, MultipleTransitionForTransaction
from workflow.strength_validators import check_edit_threshold

from workflow.logger import WORKFLOW_LOGS

APPROVAL_API_URLS = settings.__dict__['_wrapped'].__dict__['APPROVAL_API_URLS']
APPROVAL_GROUPS = settings.__dict__['_wrapped'].__dict__['APPROVAL_GROUPS']
WORKFLOW_MODEL_LIST = settings.__dict__['_wrapped'].__dict__['WORKFLOW_MODEL_LIST']


def approval_workflow(**kwargs):
    """
    :param kwargs: data dict
    :return: returns to calling funtion
    :rtype:
    """

    if kwargs["model"].lower() not in WORKFLOW_MODEL_LIST:
        WORKFLOW_LOGS.debug(f'{kwargs["model"].lower()} Not Registered with Workflow, '
                            f'ModelNotRegisteredWithWorkflowException Raised -- From User -- {kwargs["request"].user}')
        raise ModelNotRegisteredWithWorkflowException

    context_model = apps.get_model(kwargs["app"], kwargs["model"])
    context_obj = context_model.objects.get(pk=kwargs["pk"])
    current_obj_state = context_obj.status
    transaction_dict = {"app_name": kwargs["app"].lower(), "model_name": kwargs["model"].lower(), "request_id": str(kwargs["pk"]),
                        "action": kwargs["action"], "approver": __get_approver_type(kwargs["request"], kwargs['requesting_approvers'], kwargs['action'])[0],
                        "approver_type": __get_approver_type(kwargs["request"], kwargs['requesting_approvers'], kwargs['action'])[1], "remarks": kwargs["remarks"],
                        "approver_user_if_group": kwargs["request"].user.username}

    WORKFLOW_LOGS.info(f'Processing Workflow -- Trans Dict -- {transaction_dict} -- From User -- {kwargs["request"].user}')
    return __process_workflow(transaction_dict, kwargs, current_obj_state)


def __get_approver_type(request, requesting_approvers, action):
    """
    Returns the final approvers, with common or intersection with requesting approvers from UI dropdown
    or user's total groups
    :param request: http request object
    :param requesting_approvers: list of approvers, coming from workflow UI Dropdown
    :param action: Action of the transaction
    :return: list of final approver groups after common & intersection
    :rtype: list
    """
    common_group = list(set(request.user.groups.values_list("name", flat=True)) & set(APPROVAL_GROUPS))
    if requesting_approvers:
        WORKFLOW_LOGS.debug(f'Got the Requesting Approvers from UI -- {requesting_approvers} -- From User -- {request.user}')
        final_approvers = set(common_group).intersection(requesting_approvers if requesting_approvers else [])
        if len(final_approvers) > 0:
            WORKFLOW_LOGS.info(f'Final Approvers for Workflow -- {final_approvers} -- From User -- {request.user}')
            return list(final_approvers), "Group"
        else:
            WORKFLOW_LOGS.debug(f'No Final Approvers Found, '
                                f'raised MatchingApproverGroupNotFoundException -- From User -- {request.user}')
            raise MatchingApproverGroupNotFoundException
    elif not requesting_approvers and action == 'Init':
        WORKFLOW_LOGS.info(f'Initiate Approver -- {request.user} -- From User -- {request.user}')
        return request.user.username, "User"
    elif not requesting_approvers:
        WORKFLOW_LOGS.debug(f'NO Requesting Approvers from UI -- {requesting_approvers} -- From User -- {request.user}')
        final_approvers = set(common_group).difference(requesting_approvers if requesting_approvers else [])
        if len(final_approvers) > 0:
            WORKFLOW_LOGS.info(f'Final Approvers for Workflow -- {final_approvers} -- From User -- {request.user}')
            return list(final_approvers), "Group"
        else:
            WORKFLOW_LOGS.debug(f'No Final Approvers Found, '
                                f'raised MatchingApproverGroupNotFoundException -- From User -- {request.user}')
            raise MatchingApproverGroupNotFoundException


def __get_current_status_for_obj(pk, app, model):
    """
    To get the current status, of the model object, of which workflow is registered
    :param pk: PK of the object
    :param app: app name
    :param model: model name
    :return: status of object, i.e status field
    :rtype: string
    """
    model_obj = apps.get_model(app, model)
    obj = model_obj.objects.get(pk=pk)
    return obj.status


def __get_next_transition_from_current(current_transition, transaction_dict):
    """
    to get the next transition, from current
    :param current_transition: workflow transition object
    :return: next transition
    :rtype: workflow transition object
    """
    next_transition = WorkflowTransitions.objects.filter(current_state=current_transition.next_state,
                                                         action=current_transition.action, is_active=True,
                                                         app_name=current_transition.app_name,
                                                         model_name=current_transition.model_name)
    if next_transition:
        validate_transition = __validate_constraints(next_transition, transaction_dict["request_id"])
        if validate_transition.__len__() > 1:
            raise MultipleTransitionForTransaction
        if not validate_transition:
            raise NoMatchingTransitionFoundException

        return validate_transition[0]
    else:
        WORKFLOW_LOGS.debug(f'No Matching Next Transition Master Found From Current, '
                            f'raised NoMatchingTransitionFoundException')
        raise NoMatchingTransitionFoundException

def expire_all_approval_links(app, model, request_id):
    """
    expire all the approval links for current object
    :param app: app name
    :param model: model name
    :param request_id: PK of the object
    :return: None
    :rtype: None
    """
    ApprovalLinkProxy.objects.filter(app__iexact=app, model__iexact=model, request_id=request_id).update(is_valid=False)
    WORKFLOW_LOGS.info(f'Expired All Approval Links for app -- {app} -- model -- {model} -- request_id -- {request_id}')

def __process_workflow(transaction_dict, kwargs, current_obj_state):
    """
    Purpose: Processing the approval workflow based on the action and the approver
    :param transaction_dict: Initial state of the current transaction
    :param kwargs: {request, app, model, pk, action, remarks}
    :param current_obj_state: current status of the object, for which workflow is to be process
    :return: Current status of the approval workflow
    """
    user_action = validate_action_of_workflow(transaction_dict)
    # User approves
    if user_action == ACTION_VALIDATOR["approval"]:
        with transaction.atomic():
            WORKFLOW_LOGS.info(f'Initiating APPROVAL for app -- {transaction_dict["app_name"]} '
                               f'-- model -- {transaction_dict["model_name"]} -- request_id -- {transaction_dict["request_id"]}')
            request_status, workflow_completed = __perform_approval(transaction_dict, kwargs, current_obj_state)
    # User rejects
    elif user_action == ACTION_VALIDATOR["rejection"]:
        with transaction.atomic():
            WORKFLOW_LOGS.info(f'Initiating REJECTION for app -- {transaction_dict["app_name"]} '
                               f'-- model -- {transaction_dict["model_name"]} -- request_id -- {transaction_dict["request_id"]}')
            request_status, workflow_completed = __perform_rejection(transaction_dict, kwargs, current_obj_state)
    # User initiates
    elif user_action == ACTION_VALIDATOR["init"]:
        with transaction.atomic():
            WORKFLOW_LOGS.info(f'Initiating INIT for app -- {transaction_dict["app_name"]} '
                               f'-- model -- {transaction_dict["model_name"]} -- request_id -- {transaction_dict["request_id"]}')
            request_status, workflow_completed = __perform_initiation(transaction_dict)
    # No action registered
    else:
        WORKFLOW_LOGS.debug(f' {user_action} Is Not A Valid Action, raised InvalidActionException for '
                            f'-- app -- {transaction_dict["app_name"]} -- model -- {transaction_dict["model_name"]} '
                            f'-- request_id -- {transaction_dict["request_id"]}')
        raise InvalidActionException

    return request_status, workflow_completed


def __perform_approval(transaction_dict, kwargs, current_obj_state):
    """
    performa approval, i.e forwards state with creating Transaction logs
    :param transaction_dict: data dict
    :param kwargs: data dict
    :param current_obj_state: current state of the object, for which state is to be forwarded
    :return: after forward status & is_approved flag i.e true/ false
    :rtype: string / bool
    """
    strength_achieved = False
    current_transition = __get_current_transition_by_transaction(transaction_dict, current_obj_state)
    WORKFLOW_LOGS.info(f'Current Transition Found -- {current_transition} -- From Trans Dict -- {transaction_dict} '
                       f'-- for app -- {transaction_dict["app_name"]} -- model_name -- {transaction_dict["model_name"]}'
                       f' -- request_id -- {transaction_dict["request_id"]}')
    if not current_transition:
        WORKFLOW_LOGS.debug(f'NO Current Transition Found From Transaction Dict -- {transaction_dict}, '
                            f'raised NoMatchingTransitionFoundException for -- app -- {transaction_dict["app_name"]} '
                            f'-- model_name -- {transaction_dict["model_name"]} -- request_id -- {transaction_dict["request_id"]}')
        raise NoMatchingTransitionFoundException
    if current_transition.is_parallel_trans:
        action_plan = json.loads(current_transition.action_plan)
        current_requesting_approvers = list(set(action_plan['approvers']) & set(transaction_dict['approver']))
    else:
        current_requesting_approvers = transaction_dict['approver']
    for approver in current_requesting_approvers:
        if current_transition.is_parallel_trans:
            is_allocated_strength_valid, last_transaction = check_allocated_strength_validity(current_transition, transaction_dict, approver)
            if is_allocated_strength_valid:
                trans_log_object, transaction_dict, strength_achieved = create_transactions_parallel(current_transition, transaction_dict, approver, last_transaction)
            else:
                WORKFLOW_LOGS.debug(f'PARALLEL -- Strength Validation failed for approver -- {approver}, '
                                    f'raised ActionAlreadyTakenException for '
                                    f'-- app -- {transaction_dict["app_name"]} -- model_name -- {transaction_dict["model_name"]} '
                                    f'-- request_id -- {transaction_dict["request_id"]}')
                raise ActionAlreadyTakenException(approver)
        else:
            is_allocated_strength_valid, last_transaction = check_allocated_strength_validity\
                (current_transition, transaction_dict, approver)
            if is_allocated_strength_valid:
                trans_log_object, transaction_dict = create_transactions_normal(current_transition, transaction_dict, approver, last_transaction)
            else:
                WORKFLOW_LOGS.debug(f'NORMAL -- Strength Validation failed for approver -- {approver}, '
                                    f'raised ActionAlreadyTakenException for '
                                    f'-- app -- {transaction_dict["app_name"]} -- model_name -- {transaction_dict["model_name"]} '
                                    f'-- request_id -- {transaction_dict["request_id"]}')
                raise ActionAlreadyTakenException(approver)
    if current_transition.is_last_transition:
        workflow_completed = True
        request_status = current_transition.next_state
        expire_all_approval_links(transaction_dict["app_name"], transaction_dict["model_name"],
                                  transaction_dict["request_id"])
    elif current_transition.is_parallel_trans and strength_achieved:
        workflow_completed = False
        request_status = current_transition.next_state
    elif current_transition.is_parallel_trans and not strength_achieved:
        workflow_completed = False
        request_status = current_transition.current_state
    else:
        workflow_completed = False
        request_status = current_transition.next_state

    return request_status, workflow_completed


def __perform_initiation(transaction_dict):
    """
    performs initiation on object, with creating Init transaction log
    :param transaction_dict: data dict
    :return: after initiation status & is_approved flag i.e true/ false
    :rtype: string / bool
    """
    transaction_dict["current_state"] = WORKFLOW_STATUS['Initiated']

    transaction_dict["next_approver"], transaction_dict["next_state"], transaction_dict["next_approver_type"], \
    action_plan_defined, type_of_transition, current_transition = __get_next_approver(transaction_dict, Initiated=True)
    is_allocated_strength_valid, last_transaction = check_edit_threshold(current_transition, transaction_dict)
    if not is_allocated_strength_valid:
        WORKFLOW_LOGS.debug(f'EDIT Threshold Reached raised EditThresholdReachedException for -- app -- {transaction_dict["app_name"]} '
                            f'-- model_name -- {transaction_dict["model_name"]} '
                            f'-- request_id -- {transaction_dict["request_id"]}')
        raise EditThresholdReachedException
    transaction_dict["action_plan_executed"] = json.dumps(action_plan_defined)
    if not transaction_dict["next_approver"]:
        raise NextApproverNotFoundException
    elif type_of_transition == 'parallel':
        transaction_dict["next_approver"] = transaction_dict["next_approver"]['approvers']
    else:
        transaction_dict["next_approver"] = transaction_dict["next_approver"]
    request_status = transaction_dict["next_state"]
    workflow_completed = False
    WorkflowLog.objects.create(**transaction_dict)
    WORKFLOW_LOGS.info(f'Initiation Successful for -- app -- {transaction_dict["app_name"]} '
                       f'-- model_name -- {transaction_dict["model_name"]} '
                       f'-- request_id -- {transaction_dict["request_id"]}')
    return request_status, workflow_completed

def __perform_rejection(transaction_dict, kwargs, current_obj_state):
    """
    performs rejection, on object with creating Transaction log

    :param transaction_dict: data dict
    :param kwargs: data dict
    :param current_obj_state: current state of the object, for which rejection is to be performed
    :return: after rejection status & is_approved flag i.e true/ false
    :rtype: string / bool
    """
    validate_transition = None
    total_transaction = WorkflowTransactions.objects.filter(request_id=transaction_dict["request_id"],
                                                            model_name__iexact=transaction_dict["model_name"],
                                                            app_name__iexact=transaction_dict["app_name"],
                                                            )
    if total_transaction:
        current_transitions = WorkflowTransitions.objects.filter(model_name__iexact=transaction_dict["model_name"],
                                                            app_name__iexact=transaction_dict["app_name"],
                                                            current_state=current_obj_state,
                                                            action='Approve',
                                                            is_active=True)
        if current_transitions:
            validate_transition = __validate_constraints(current_transitions, transaction_dict["request_id"])
            if validate_transition.__len__() > 1:
                raise MultipleTransitionForTransaction
            if not validate_transition:
                raise NoMatchingTransitionFoundException

        if validate_transition:
            transaction_dict["current_state"] = validate_transition[0].current_state
            transaction_dict["next_approver"] = "[]"
            transaction_dict["next_state"] = ""
            transaction_dict["next_approver_type"] = ""
            transaction_dict['approver'] = list(set(transaction_dict["approver"]).intersection(APPROVAL_GROUPS))
            workflow_completed = True
            request_status = 'Rejected'
            WorkflowLog.objects.create(**transaction_dict)
            expire_all_approval_links(transaction_dict["app_name"], transaction_dict["model_name"],
                                      transaction_dict["request_id"])
            return request_status, workflow_completed
        else:
            raise RejectionDeniedException
    else:
        raise RejectionDeniedException

def create_transactions_normal(current_transition, transaction_dict, approver, last_transaction):
    transaction_dict["current_state"] = current_transition.current_state
    transaction_dict["next_approver"], transaction_dict["next_state"], transaction_dict["next_approver_type"], \
    action_plan_defined, type_of_transition = __get_next_approvers_from_current_transition(current_transition)
    if not current_transition.is_last_transition:
        next_transition = __get_next_transition_from_current(current_transition, transaction_dict)
        if next_transition:
            if next_transition.action_user:
                transaction_dict['next_approver'] = next_transition.action_user
            else:
                transaction_dict['next_approver'] = next_transition.action_group
        else:
            WORKFLOW_LOGS.debug(f'Next Transition not found Current, raised NextTransitionNotFoundException  -- for '
                                f'-- app -- {transaction_dict["app_name"]} -- model_name -- {transaction_dict["model_name"]} '
                                f'-- request_id -- {transaction_dict["request_id"]}')
            raise NextTransitionNotFoundException
    else:
        transaction_dict['next_approver'] = '[]'

    # for inter parallel starts
    inter_parallel_found = False
    if current_transition.is_inter_parallel:
        inter_parallel_data = try_get_inter_next_approver(current_transition, transaction_dict["next_approver"],
                                                          approver, transaction_dict["request_id"])
        inter_parallel_found = inter_parallel_data[1]
        transaction_dict["next_approver"] = inter_parallel_data[0]
    transaction_dict['was_inter_parallel'] = True if inter_parallel_found else False
    transaction_dict['was_upto_level'] = current_transition.upto_level_inter_parallel \
        if current_transition.upto_level_inter_parallel else None
    transaction_dict['level_executed'] = current_transition.level
    # for inter parallel ends

    transaction_dict["action_plan_executed"] = '{}'
    trans_log_obj = WorkflowLog.objects.create(**transaction_dict)
    WORKFLOW_LOGS.info(f'NORMAL -- Transaction Created Successfully -- {trans_log_obj} for '
                       f'-- app -- {transaction_dict["app_name"]} -- model_name -- {transaction_dict["model_name"]} '
                       f'-- request_id -- {transaction_dict["request_id"]}')
    return trans_log_obj, transaction_dict

def create_transactions_parallel(current_transition, transaction_dict, approver, last_transaction):
    transaction_dict["current_state"] = current_transition.current_state
    defined_approvers, transaction_dict["next_state"], transaction_dict["next_approver_type"], \
    action_plan_defined, type_of_transition = __get_next_approvers_from_current_transition(current_transition)
    if last_transaction:
        action_plan_defined = json.loads(last_transaction.action_plan_executed)
    action_plan_defined['strength_distribution'][approver] = action_plan_defined['strength_distribution'][approver] - 1

    # for strength allocation
    if approver in action_plan_defined['strength_allocation']:
        approved_users = action_plan_defined['strength_allocation'][approver]
        approved_users.append(transaction_dict['approver_user_if_group'])
        action_plan_defined['strength_allocation'][approver] = approved_users
    else:
        action_plan_defined['strength_allocation'][approver] = transaction_dict['approver_user_if_group'].split('#')
    # strength allocation ends here

    strength_executed_status = [action_plan_defined["strength_distribution"][group] for group in
                                action_plan_defined["strength_distribution"]]
    all_approvers_executed = all(i == 0 for i in strength_executed_status)
    transaction_dict["action_plan_executed"] = json.dumps(action_plan_defined)

    if last_transaction:
        next = list(set(json.loads(last_transaction.next_approver)) - set((approver.split('#'))))
        [next.append(approver) for i in range(0, action_plan_defined['strength_distribution'][approver]) if
         action_plan_defined['strength_distribution'][approver] > 0]
    else:
        strengthend_approvers = [i for i in action_plan_defined['strength_distribution']
                                 if action_plan_defined['strength_distribution'][i] != 0]
        next = list(set(strengthend_approvers) - set((approver.split('#'))))
        [next.append(approver) for i in range(0, action_plan_defined['strength_distribution'][approver]) if
         action_plan_defined['strength_distribution'][approver] > 0]

    if next:
        transaction_dict["next_approver"] = json.dumps(next)
    else:
        next_transition = __get_next_transition_from_current(current_transition, transaction_dict)
        transaction_dict["next_approver"] = next_transition.action_group

    transaction_dict["was_parallel"] = True
    # for inter parallel starts
    inter_parallel_found = False
    if current_transition.is_inter_parallel:
        inter_parallel_data = try_get_inter_next_approver(current_transition, transaction_dict["next_approver"], approver, transaction_dict["request_id"])
        inter_parallel_found = inter_parallel_data[1]
        transaction_dict["next_approver"] = inter_parallel_data[0]
    transaction_dict['was_inter_parallel'] = True if inter_parallel_found else False
    transaction_dict['was_upto_level'] = current_transition.upto_level_inter_parallel \
        if current_transition.upto_level_inter_parallel else None
    transaction_dict['level_executed'] = current_transition.level
    # for inter parallel ends

    trans_log_obj = WorkflowLog.objects.create(**transaction_dict)

    total_transaction = WorkflowTransactions.objects.filter(request_id=transaction_dict["request_id"],
                                                            model_name__iexact=transaction_dict["model_name"],
                                                            app_name__iexact=transaction_dict["app_name"],
                                                            current_state=current_transition.current_state,
                                                            next_state=current_transition.next_state,
                                                            action=current_transition.action)

    strength_achieved = True if all_approvers_executed else False
    return trans_log_obj, transaction_dict, strength_achieved

def __get_next_approver(transaction_dict, Initiated=False):
    """
    Purpose: Get the next approver
    only for Perform Initiation function
    :param transaction_dict: {app_name,model_name,current_state,request_id}
    :return: String - username,groupname, String - next state, String - User/Group
    """

    filters = {
        "app_name__iexact": transaction_dict["app_name"],
        "model_name__iexact": transaction_dict["model_name"],
        "current_state": transaction_dict["current_state"],
        "action": "Initiated" if Initiated else "Approve",
        "is_active": True}

    next_transitions = WorkflowTransitions.objects.filter(**filters)

    next_transitions = __validate_constraints(list(next_transitions), transaction_dict["request_id"])

    if next_transitions:

        if next_transitions[0].action_user:
            return next_transitions[0].action_user, next_transitions[0].next_state, "User", json.loads(next_transitions[0].action_plan), next_transitions[0]
        else:
            if next_transitions[0].is_parallel_trans:
                return json.loads(next_transitions[0].action_plan), next_transitions[0].next_state, "Group", json.loads(next_transitions[0].action_plan), "parallel", next_transitions[0]
            else:
                return next_transitions[0].action_group, next_transitions[0].next_state, "Group", {}, "normal", next_transitions[0]
    else:
        WORKFLOW_LOGS.debug(f'Current Transition Master Not Found from Transaction raised NoMatchingTransitionFoundException for '
                            f'-- app -- {transaction_dict["app_name"]} -- model_name -- {transaction_dict["model_name"]} '
                            f'-- request_id -- {transaction_dict["request_id"]}')
        raise NoMatchingTransitionFoundException


def __get_next_approvers_from_current_transition(current_transition):
    if current_transition:
        if current_transition.action_user:
            return current_transition.action_user, current_transition.next_state, "User", json.loads(current_transition.action_plan)
        else:
            if current_transition.is_parallel_trans:
                return json.loads(current_transition.action_plan), current_transition.next_state, "Group", json.loads(current_transition.action_plan), "parallel"
            else:
                return current_transition.action_group, current_transition.next_state, "Group", {}, "normal"
    else:

        raise NoMatchingTransitionFoundException


def __get_current_transition_by_transaction(transaction_dict, current_obj_state):
    """
    Get the current transition by transaction object
    :param transaction_dict: {app_name, model_name, action, approver}
    :return: WorkflowTransition object
    """
    # inter_parallel_history_exists = WorkflowTransactions.objects.filter(model_name=transaction_dict["model_name"],
    #                                                        app_name=transaction_dict["app_name"],
    #                                                        request_id=transaction_dict["request_id"],
    #                                                        was_inter_parallel=True)
    # if inter_parallel_history_exists:
    #     current_obj_state = try_get_dynamic_current_obj_state(transaction_dict, current_obj_state, inter_parallel_history_exists)

    filters = Q(model_name__iexact=transaction_dict["model_name"]) \
              & Q(app_name__iexact=transaction_dict["app_name"]) \
              & Q(action=transaction_dict["action"]) \
              & Q(current_state=current_obj_state) \
              & Q(is_active=True)

    if transaction_dict["approver_type"] == "User":
        filters &= Q(action_user=transaction_dict["approver"])
    else:
        approvers = list(set(transaction_dict["approver"]).intersection(APPROVAL_GROUPS))
        for apprv in approvers:
            filters &= Q(action_group__icontains='"' + apprv + '"')

    # Determine the actions possible by the user
    # current_transition = WorkflowTransitions.objects.filter(filters).first()
    current_transitions = WorkflowTransitions.objects.filter(filters)
    validate_transition = __validate_constraints(current_transitions, transaction_dict["request_id"])
    if validate_transition.__len__() > 1:
        raise MultipleTransitionForTransaction
    if not validate_transition:
        raise NoMatchingTransitionFoundException

    return validate_transition[0]


def __validate_constraints(next_transitions, pk):
    """
    Purpose: To validate the constraints for the next transitions
    :param next_transitions: List of transitons objects
    :param pk: id of the data on which approval workflow is applied
    :return: boolean
    """

    final_transitions = []

    # Traversing multiple transitions
    for transition in next_transitions:

        # Get all the constraint in a single transition
        constraints = transition.constraints.all()

        # Checking if constraint is available
        if constraints.exists():
            is_all_constraints_valid = True

            # Traversing multiple constraints
            for constraint in constraints:

                # Checking if constraint is satisfied
                if not constraint.is_satisfied(transition, pk):
                    is_all_constraints_valid = False

            if is_all_constraints_valid:
                final_transitions.append(transition)

        else:
            final_transitions.append(transition)

    return final_transitions

def get_hierarchy_by_request(request_data):
    """
    Purpose: To generate the hierarchy based on the request by evaluating constraints
    :param request_data: Next request object's data
    :return: Workflow Transitions List
    """
    app_name, model_obj = retrieve_correct_app(request_data["model_name"])
    all_transitions = WorkflowTransitions.objects.filter(model_name__iexact=model_obj._meta.model_name.lower(),
                                                         app_name__iexact=app_name, is_active=True).order_by('level')

    approval_transitions = []

    for transition in list(all_transitions):
        if transition.action == 'Approve' or transition.action == 'Initiated':
            approval_transitions.append(transition)

    hierarchy_transitions = __validate_constraints(approval_transitions, request_data["pk"])

    if hierarchy_transitions:
        return hierarchy_transitions
    else:
        return None


def get_all_transactions(request_data):
    app_name, model_obj = retrieve_correct_app(request_data["model_name"])
    all_transactions = WorkflowTransactions.objects.filter(model_name__iexact=model_obj._meta.model_name.lower(),
                                                           app_name__iexact=app_name,
                                                           request_id=request_data["pk"])

    return all_transactions

def indicate_approval_type(request, app, model,request_id):
    app, model_obj = retrieve_correct_app(model)
    model = model_obj._meta.model_name
    data = {"pk": str(request_id),
            "app_name": app,
            "model_name": model}
    custom_transactions = get_all_transactions(data)

    groups = request.user.groups.all()
    approval_groups = [group.name for group in groups if group.name in APPROVAL_GROUPS]

    if custom_transactions:
        last_transaction = custom_transactions.last()
        next_approvers = json.loads(last_transaction.next_approver)
        approvals = list(set(approval_groups).intersection(next_approvers))
        return {'approval_type': approvals}
    else:
        return {'approval_type': approval_groups}


def to_show_approval_button(request, request_id, model_obj):
    """
    Purpose: To show approval button in the workflow section
    :param request: Network request object
    :param request_id: Id of the data on which approval workflow is applied
    :return: boolean
    """

    data_obj = model_obj.objects.get(pk=request_id)
    if data_obj.is_approved:
        return False
    transactions = WorkflowTransactions.objects.filter(request_id=request_id,
                                                           app_name__iexact=model_obj._meta.app_label,
                                                           model_name__iexact=model_obj._meta.model.__name__).order_by(
        "-id")

    if transactions:
        last_transaction = transactions[0]
    else:
        return False

    # If the last transaction was of User Init/Approval
    if last_transaction and last_transaction.action == "Approve" or last_transaction.action == "Init":
        groups = request.user.groups.all()
        approval_groups = [group.name for group in groups if group.name in APPROVAL_GROUPS]
        # If user groups exist in approval_groups
        if approval_groups:
            # Iterating each approval group
            for group in approval_groups:
                # If the last transaction's next approver matches with the user's group
                # Convert into hooks
                if group in json.loads(last_transaction.next_approver) and last_transaction.next_approver_type == "Group":
                    return True
            else:
                return False
        # If the last transaction's next approver matches with the user name
        elif last_transaction.next_approver == request.user.username and last_transaction.next_approver_type == "User":
            return True
    return False


def apply_workflow_action(request, result_return=False):
    """
    Function to proceed with Workflow initiated from the
    approval landing page of a model

    Retrieve token from request
    Verify the token against Approval link entries
    Reject all cases of invalid tokens or inexistent entries
    If valid token, get the model entry against this token
    Process workflow for the model entry and invalidate the current token

    All other valid tokens for the same model entry, will be invalidated.
    For the code, check post_save function for ApprovalProxy

    :return: response with either error or data, with HTTP status code
    :rtype: Response class object
    """

    # TODO Recheck if this function is repeating any of the Workflowuthentication class methods

    approval_token = request.META.get('HTTP_APPROVAL_AUTHORIZATION')
    is_token_exists = ApprovalLinkProxy.objects.filter(approval_token=approval_token)
    if is_token_exists.exists():
        token_in_db = ApprovalLinkProxy.objects.filter(approval_token=approval_token)
        token = token_in_db.first()

        app = token.app
        model = token.model
        request_id = token.request_id
    else:
        data = request.data
        app, model_obj = retrieve_correct_app(data['model_name'])
        # app = data['app_name']
        model = model_obj._meta.model_name
        request_id = data['id']

    context_model = apps.get_model(app, model)
    context_object = context_model.objects.filter(pk=request_id)

    if not context_object.exists():
        return Response({"error": "No such model was found"},
                        status=status.HTTP_404_NOT_FOUND)
    else:
        # IDEA : Object found, process workflow and update the model
        this_object = context_object.first()

        req_status, is_approved = approval_workflow(app=app,
                                                    model=model,
                                                    pk=this_object.pk,
                                                    action=request.data["action"],
                                                    remarks=request.data.get("remarks"),
                                                    request=request,
                                                    requesting_approvers=request.data.get('approval_type'))

         #to set last_updated_by
        this_object.status = req_status
        this_object.is_approved = is_approved
        this_object.last_updated_by = request.user.username
        this_object.save()
        
        # used save to allow for any event triggers to happen smoothly

        if is_token_exists.exists():
            last_transaction = WorkflowTransactions.objects.filter(app_name__iexact=app, model_name__iexact=model,
                                                                   request_id=request_id).last()

            if last_transaction.approver_type == "Group":
                print("----------------",last_transaction.__dict__)
                if last_transaction.next_approver=='':
                    current_transition = WorkflowTransitions.objects.filter(
                        app_name__iexact=app,
                        model_name__iexact=model,
                        next_state=last_transaction.current_state, is_active=True).first()
                else:
                    current_transition = WorkflowTransitions.objects.filter(
                        app_name__iexact=app,
                        model_name__iexact=model,
                        next_state=last_transaction.next_state, is_active=True).first()
                try:
                    # TODO FIND A BETTER METHOD
                    # to_invalidate_all = __validate_strength_completion(current_transition, last_transaction.__dict__, False)
                    token.self_invalidate(False)
                except Exception as exc:
                    print(traceback.format_exc())
            else:
                token.self_invalidate()

        if this_object.is_approved is True:
            # Invalidate all tokens on Final approval
            existing_tokens = ApprovalLinkProxy.objects.filter(app__iexact=app,model__iexact=model,request_id=request_id)
            existing_tokens.update(is_valid=False)

        if result_return:
            return
        else:
            return Response({}, status=status.HTTP_200_OK)


def get_model_info(request):
    approval_token = request.META.get('HTTP_APPROVAL_AUTHORIZATION')
    default_dict = {}

    token_found = ApprovalLinkSent.objects.filter(approval_token=approval_token, approver=request.user,
                                                         is_valid=True)

    if token_found.exists():
        token = token_found.first()
        default_dict['app'] = token.app
        default_dict['model'] = token.model
        default_dict['request_id'] = token.request_id
        default_dict['username'] = request.user.username
        auth_token, created = Token.objects.get_or_create(user=request.user)
        default_dict['auth_token'] = '"Token {}"'.format(auth_token.key)
        url = APPROVAL_API_URLS[token.model.lower()]
        if url:
            default_dict['approval_api_url'] = url.format(pk=str(token.request_id))
        return default_dict
    return {}

