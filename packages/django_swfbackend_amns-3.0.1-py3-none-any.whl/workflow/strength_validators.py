import json

from workflow.models import WorkflowTransactions




def check_allocated_strength_validity(current_transition, transaction_dict, current_approver):
    """
    validates strength, for the given transition

    :param current_transition: current transiiton object
    :type current_transition: WorkflowtransitionMaster
    :param transaction_dict: data dict
    :type transaction_dict: dict
    :param current_approver: current requesting approver group
    :type current_approver: string
    :return: is_valid / last transaction if exists of current tranisiton
    :rtype: bool / WorkflowTransaction
    """
    if current_transition.approval_strength > 0 and current_transition.is_parallel_trans:

        return check_parallel_transaction_validity(current_transition, transaction_dict, current_approver)

    elif current_transition.approval_strength > 0 and not current_transition.is_parallel_trans:

        return check_normal_transaction_validity(current_transition, transaction_dict, current_approver)
    else:
        return True, None


def check_normal_transaction_validity(current_transition, transaction_dict, current_approver):
    """
    validates Normal transition
    :param current_transition: current transiiton object
    :type current_transition: WorkflowtransitionMaster
    :param transaction_dict: data dict
    :type transaction_dict: dict
    :param current_approver: current requesting approver group
    :type current_approver: string
    :return: is_valid / last transaction if exists of current tranisiton
    :rtype: bool / WorkflowTransaction
    """
    total_transaction = WorkflowTransactions.objects.filter(request_id=transaction_dict["request_id"],
                                                            model_name__iexact=transaction_dict["model_name"],
                                                            app_name__iexact=transaction_dict["app_name"],
                                                            # approver__contains=current_approver,
                                                            current_state=current_transition.current_state,
                                                            next_state=current_transition.next_state,
                                                            action=current_transition.action)
    if (int(total_transaction.count()) > 0 and int(total_transaction.count()) <= current_transition.approval_strength):
        last_transaction = total_transaction.last()

        return True, last_transaction
    elif not total_transaction and current_transition.approval_strength > 0:

        return True, None
    else:

        return False, None


def check_parallel_transaction_validity(current_transition, transaction_dict, current_approver):
    """
    validates parallel transition, for the aciton plan defined in transition master
    :param current_transition: current transiiton object
    :type current_transition: WorkflowtransitionMaster
    :param transaction_dict: data dict
    :type transaction_dict: dict
    :param current_approver: current requesting approver group
    :type current_approver: string
    :return: is_valid / last transaction if exists of current tranisiton
    :rtype: bool / WorkflowTransaction

    """
    total_transaction = WorkflowTransactions.objects.filter(request_id=transaction_dict["request_id"],
                                                            model_name__iexact=transaction_dict["model_name"],
                                                            app_name__iexact=transaction_dict["app_name"],
                                                            current_state=current_transition.current_state,
                                                            next_state=current_transition.next_state,
                                                            action=current_transition.action)

    if (int(total_transaction.count()) > 0 and int(total_transaction.count()) <= current_transition.approval_strength):
        last_transaction = total_transaction.last()
        action_plan_executed = json.loads(last_transaction.action_plan_executed)
        if action_plan_executed['strength_distribution'][current_approver] != 0:
            if current_approver in action_plan_executed['strength_allocation']:
                approved_users = action_plan_executed['strength_allocation'][current_approver]
                if transaction_dict['approver_user_if_group'] in approved_users:
                    return False, last_transaction
            return True, last_transaction
        else: return False, None

    elif not total_transaction:
        action_plan = json.loads(current_transition.action_plan)
        if action_plan['strength_distribution'][current_approver] == 0:
            return False, None
        return True, None
    else: return False, None


def check_edit_threshold(current_transition, transaction_dict):
    total_transaction = WorkflowTransactions.objects.filter(request_id=transaction_dict["request_id"],
                                                            model_name__iexact=transaction_dict["model_name"],
                                                            app_name__iexact=transaction_dict["app_name"],
                                                            # approver__contains=current_approver,
                                                            current_state=current_transition.current_state,
                                                            next_state=current_transition.next_state,
                                                            action='Init')
    if (int(total_transaction.count()) > 0 and int(total_transaction.count()) <= current_transition.approval_strength):
        last_transaction = total_transaction.last()
        return True, last_transaction
    elif not total_transaction and current_transition.approval_strength > 0:
        return True, None
    else:
        return False, None

