import functools

from django.utils.module_loading import import_string

from api.logger_directory import requests_logger
from commons.functions import get_hooks

DECORATOR_LOG = requests_logger()


class TriggerException(Exception):
    def __init__(self, error_dict):
        self.error_dict = error_dict


def triggeraction(function):
    @functools.wraps(function)
    def wrap(request, app, model, pk):
        can_process_workflow = False
        # Check if the action corresponds to a Process Workflow action

        request_data = request.data

        # TODO New method to find if current transition is has a precondition process

        if request_data.get('action'):
            DECORATOR_LOG.info("No process required. Back to {}".format(function))
            return function(request, request_data, app, model, pk)

        # Find a hook on the current model and action
        hook_config = get_hooks(app, "WORKFLOW_ACTIONS_TRIGGER", {})

        # If hook not found, return. Else import functions
        if not hook_config:
            DECORATOR_LOG.warn("Could not find any such hook")
            raise TriggerException({"error": "Could not find any such hook"})

        function_path = hook_config.get(model).get(request_data['status'])

        DECORATOR_LOG.info("Function path : {}".format(function_path))

        if not function_path:
            DECORATOR_LOG.warn("Could not find any function paths specified")
            raise TriggerException({"error": "Could not find any function paths specified"})

        imported_function = import_string(function_path)

        # Execute function with the given args
        can_process_workflow = imported_function(request, app, model, pk)

        # If execution completes use the result to decide on the next course of action
        if can_process_workflow is True:
            DECORATOR_LOG.info("Execution successful returning {}".format(function))
            return function(request, request_data, app, model, pk)
        else:
            raise TriggerException({"error": "Execution of process was unsuccessful"})

    return wrap
