def __validate_constraints(next_transitions, pk):
    """
    Purpose: To validate the constraints for the next transitions
    :param next_transitions: List of transitons objects
    :param pk: id of the data on which approval workflow is applied
    :return: boolean
    """

    final_transitions = []

    # Traversing multiple transitions
    for transition in next_transitions:

        # Get all the constraint in a single transition
        constraints = transition.constraints.all()

        # Checking if constraint is available
        if constraints.exists():
            is_all_constraints_valid = True

            # Traversing multiple constraints
            for constraint in constraints:

                # Checking if constraint is satisfied
                if not constraint.is_satisfied(transition, pk):
                    is_all_constraints_valid = False

            if is_all_constraints_valid:
                final_transitions.append(transition)

        else:
            final_transitions.append(transition)

    return final_transitions