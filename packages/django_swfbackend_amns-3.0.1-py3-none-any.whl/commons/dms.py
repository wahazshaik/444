from commons.dms_model import DmsModel
from commons.dms_config import digest_header, generic_header, \
    rename_header, accept_header, delete_header, create_header
import requests
from requests_ntlm import HttpNtlmAuth


class MossDms:
    def __str__(self) -> str:
        return "MossDms Object" + str(self.__sharePointUrl)

    def __repr__(self) -> str:
        return "MossDms Object" + str(self.__sharePointUrl)

    def __init__(self, sharePointUrl, username, password):
        self.__sharePointUrl = sharePointUrl
        self.__username = username
        self.__password = password
        self.__digest = self.__get_digest()
        self.dmsModel = DmsModel()

    def __get_digest(self):
        """
        get the Digest Value
        :param SharepointURl:
        :param username:the username
        :param password:the password
        :return:Digest Value for requests
        """
        try:
            res = requests.post(self.__sharePointUrl + "/_api/contextinfo",
                                auth=HttpNtlmAuth(self.__username, self.__password),
                                headers=digest_header)
            formdigest = res.json()['d']['GetContextWebInformation']['FormDigestValue']
            return formdigest
        except Exception as e:
            raise e

    def get_absolute_url(self, filename):
        """
        Get the Absolurte URl of the Document
        :param filename: filename to retrieve
        :return:
        """
        # TODO : not working function
        generic_header['x-requestdigest'] = self.__digest
        RequestURl = self.__sharePointUrl + "_api/Web/Lists/getByTitle('{}')/items?$select=FileRe".format(
            filename)
        get = requests.post(RequestURl, auth=HttpNtlmAuth(self.__username, self.__password), headers=generic_header,
                            )

    def upload(self, relativefolderurl, fobj, fname):
        """
        Uploads the File in the Relative folder
        :param relativefolderurl: Relative folder url
        :param fobj: generic file object
        :param fname: name of the file
        :return: response-status, file-name, sharepoint-path
        """
        try:
            # file = open(fobj, 'rb')
            data = fobj.read()
            generic_header['x-requestdigest'] = self.__digest
            requestUrl = self.__sharePointUrl + self.dmsModel.get_upload_url().format(
                relativefolderurl, fname)
            upload_result = requests.post(requestUrl, auth=HttpNtlmAuth(self.__username, self.__password),
                                          headers=generic_header, data=data)
            res_dict = upload_result.json()
            print(res_dict)
            print(upload_result.status_code)
            return upload_result.status_code, res_dict['d']['Name'], res_dict['d']['ServerRelativeUrl']
        except Exception as e:
            raise e

    def RenameFolder(self, relativefolderurl, newname):
        """
        Renames the folder of relative url
        :param relativefolderurl: Relative folder url
        :param newname: the new filename
        :return: response-status, file-name, sharepoint-path
        """
        try:
            requestUrl = self.__sharePointUrl + self.dmsModel.get_rename_url().format(
                relativefolderurl)
            generic_header["IF-MATCH"] = "*"
            rename_header['x-requestdigest'] = self.__digest
            response = requests.get(requestUrl, auth=HttpNtlmAuth(self.__username, self.__password),
                                    headers=generic_header)
            body = {'__metadata': {'type': response.json()['d']['__metadata']['type']}, 'Title': newname,
                    'FileLeafRef': newname}
            res = requests.post(requestUrl, auth=HttpNtlmAuth(self.__username, self.__password), headers=rename_header,
                                json=body)
            res_dict = res.json()
            return res.status_code, res_dict['d']['Name'], res_dict['d']['ServerRelativeUrl']
        except Exception as e:
            raise e

    def RetrieveAllFiles(self, relativefolderurl):
        """
        Retrieve all the files of folder
        :param relativefolderurl: Relative folder path
        :return: filename : sharepoint path
        """
        try:
            RequestUrl = self.__sharePointUrl + self.dmsModel.get_retriveallfiles_url().format(
                relativefolderUrl=relativefolderurl)

            response = requests.get(RequestUrl, auth=HttpNtlmAuth(self.__username, self.__password),
                                    headers=accept_header)
            response_dict = response.json()
            info = {}
            # print(response.json()['d']['results'][0],"##########")
            for i in response_dict['d']['results']:
                info[i['Name']] = i['ServerRelativeUrl']
            return info
        except Exception as e:
            raise e

    def RetrieveFile(self, relativefolderurl, filename):
        """
        Retrieve specific file of the folder
        :param relativefolderurl: the relative folder path
        :param filename: the filename to fetch in the folder
        :return: Bytes of the file
        """
        # / $value
        try:
            RequestUrl = self.__sharePointUrl + self.dmsModel.get_retrivefile_url().format(
                relativefolderurl, filename)
            res = requests.get(RequestUrl, auth=HttpNtlmAuth(self.__username, self.__password), headers=accept_header)
            return res.content
        except Exception as e:
            raise e

    def DeleteFolder(self, relativefolderurl):
        """
        Deletes the folder
        :param relativefolderurl: relative folder sharepoint path
        :return: response status-code
        """
        try:
            RequestUrl = self.__sharePointUrl + self.dmsModel.get_deletefolder_url().format(relativefolderurl)
            delete_header['x-requestdigest'] = self.__digest
            res = requests.post(RequestUrl, auth=HttpNtlmAuth(self.__username, self.__password), headers=delete_header)
            return res.status_code
        except Exception as e:
            raise e

    def DeleteFile(self, relativeserverurl, relativefilerurl, filename):
        """
        Deletes the file Specified of the folder
        :param relativefilerurl:
        :return: response-statuscode
        """
        try:
            finalurl = '/' + relativeserverurl + "/" + relativefilerurl + "/" + filename
            RequestUrl = self.__sharePointUrl + self.dmsModel.get_deletefile_url().format(
                relativefolderUrl=finalurl)
            delete_header['x-requestdigest'] = self.__digest
            res = requests.post(RequestUrl, auth=HttpNtlmAuth(self.__username, self.__password), headers=delete_header)
            return res.status_code
        except Exception as e:
            raise e

    def CreateRelativeFolder(self, relativeUrl, newFolderName):
        """
        Creates the new folder
        :param relativeUrl:the relative path into which the folder to be created
        :param newFolderName: the Folder name
        :return:
        """
        try:
            RequestUrl = self.__sharePointUrl + self.dmsModel.get_createfolder_url().format(relativeUrl, newFolderName)
            create_header['x-requestdigest'] = self.__digest
            response = requests.post(RequestUrl, auth=HttpNtlmAuth(self.__username, self.__password),
                                     headers=create_header)
            return response.status_code
        except Exception as e:
            raise e

    def CreateDepthFolders(self, rootrelativeurl, *depths):
        """
        creates in Depth folders
        :param rootrelativeurl:
        :param depths:
        :return:
        """
        for i in depths:
            # print(rootrelativeurl + '/' +str(i))
            self.CreateRelativeFolder(rootrelativeurl, i)
            rootrelativeurl = rootrelativeurl + '/' + str(i)

    def CreateFoldersIn(self, relativeurl, *folders):
        """
        Creates Multiple folders in
        :param relativeurl:
        :param folders:
        :return:
        """
        for i in folders:
            self.CreateRelativeFolder(relativeurl, str(i))

    def CreateFolderAndMultipleUpload(self, relativefolderurl, foldername, files):
        """
        specific for django file objects
        i.e request.FILES
        """
        self.CreateRelativeFolder(relativefolderurl, foldername)
        files = [i for i in files.values()]
        for f in files:
            self.upload(relativefolderurl + '/' + foldername, f.file, f.name)
            # response = map(lambda x:self.UploadFile(relativefolderurl,x.file,x.name), d)
            #

    def CreateFolderAndUploadFile(self, relativefolderurl, file):
        self.CreateRelativeFolder(relativefolderurl, file.name)
        self.upload(relativefolderurl + '/' + file.name, file.file, file.name)