
class DmsModel:

    uploadUrl = "/_api/web/GetFolderByServerRelativeUrl('{}')/Files/add(url='{}',overwrite=true)"
    renameUrl = "/_api/web/GetFolderByServerRelativeUrl('{}')/ListItemAllFields"
    retrieveAllFilesUrl = "/_api/web/GetFolderByServerRelativeUrl('{relativefolderUrl}')/Files"
    retrieveFileUrl = "/_api/web/GetFolderByServerRelativeUrl('{}')/Files('{}')/$value"
    deleteFolderUrl = "/_api/web/GetFolderByServerRelativeUrl('{}')"
    deleteFileURl = "/_api/web/GetFileByServerRelativeUrl('{relativefolderUrl}')"
    createFolderurl = "/_api/web/GetFolderByServerRelativeUrl('{}')/Folders/add('{}')"

    def get_upload_url(self):
        return self.uploadUrl

    def set_upload_url(self, newUploadUrl):
        self.UploadUrl = newUploadUrl

    def get_rename_url(self):
        return self.renameUrl

    def set_rename_url(self,newRenameUrl):
        self.renameUrl = newRenameUrl

    def get_retriveallfiles_url(self):
        return self.retrieveAllFilesUrl

    def set_retriveallfiles_url(self,newUrl):
        self.retrieveAllFilesUrl = newUrl

    def get_retrivefile_url(self):
        return self.retrieveFileUrl

    def set_retrivefile_url(self,newUrl):
        self.retrieveFileUrl = newUrl

    def get_deletefolder_url(self):
        return self.deleteFolderUrl

    def set_deletefolder_url(self, newUrl):
        self.deleteFolderUrl= newUrl

    def get_deletefile_url(self):
        return self.deleteFileURl

    def set_deletefile_url(self, newUrl):
        self.deleteFileURl= newUrl

    def get_createfolder_url(self):
        return self.createFolderurl

    def set_createfolder_url(self, newUrl):
        self.createFolderurl = newUrl

