import pickle

#import pika
import pika
from django.apps import apps
from django.conf import settings
from django.template.loader import get_template

from commons.constants import  PUBLISH_MAIL_DICT
from commons.message_sender import send_message, rabbit_connection

RABBITMQ_CONF = settings.__dict__['_wrapped'].__dict__['RABBITMQ_CONF']

def send_email(message):
    """
    Wrapper function which can send email

    :param email_addresses: List of valid email addresses
    :param credentials: User Credentials containing username & password
    :return: Email Message dictionary as required by ZMQ
    :rtype: dict
    """

    RABBITMQ_CON_URL = RABBITMQ_CONF["RABBITMQ_CON_URL"]

    body = pickle.dumps(message)

    channel = rabbit_connection()
    connection = pika.BlockingConnection(pika.URLParameters(RABBITMQ_CON_URL))

    try:

        if connection.is_closed:
            channel = rabbit_connection()

        send_message(channel, body)
    except Exception as e:
        if str(e).__contains__('Stream connection lost: ConnectionResetError'):
            channel = rabbit_connection()
            send_message(channel, body)


def set_email_fmt(**kwargs):
    """
    Function returns a substituted copy of the mail dictionary needed by ZMQ

    Essentially a setter function

    :param mail_subject: Mail Subject
    :param mail_content: Mail Body
    :param to_list: To List
    :param cc_list: CC List
    :param bcc_list: BCC List
    :return: Substituted dictionary
    :rtype: dict
    """

    mail_fmt = PUBLISH_MAIL_DICT.copy()
    mail_fmt.update(**kwargs)
    mail_fmt.update(RABBITMQ_CONF["MAIL_CREDENTIALS"])
    return mail_fmt


def prepare_email_message(email_code, mail_subject, to_list, cc_list, workflow_log=None, extra_args={}):
    """
    Function to prepare email templates to send

    :param email_code: Email mnemonic that denotes the content of the mail
    :param to_list: Email addresses this email is addressed to
    :param cc_list: Email addresses in CC
    :param workflow_log: WorkflowState instance
    :return: message: Dictionary compliant with the current message library
    :rtype: dict
    """

    cc_list.extend(["jatin.parmar@amns.in", "rushabh.shah@amns.in", "jagat.pathak@amns.in", "bhupendra.kumar@amns.in"])

    to = ','.join(to_list) or None
    cc = ','.join(cc_list) or None

    mail_content = render_html_message(workflow_log, email_code, extra_args)

    message = set_email_fmt(mail_subject=mail_subject, mail_content=mail_content,
                            to=to, cc=cc)
    return message


def prepare_email_message_simple(mail_subject, to_list, cc_list, mail_content):
    """
    Function to prepare email templates to send

    :param email_code: Email mnemonic that denotes the content of the mail
    :param to_list: Email addresses this email is addressed to
    :param cc_list: Email addresses in CC
    :param workflow_log: WorkflowState instance
    :return: message: Dictionary compliant with the current message library
    :rtype: dict
    """
    to = ','.join(to_list) or None
    cc = ','.join(cc_list) or None

    message = set_email_fmt(mail_subject=mail_subject, mail_content=mail_content,
                            to=to, cc=cc)
    return message


def render_html_message_simple(email_code, context={}):
    # IDEA: Get model object using pk, fetch values and render into mail body

    html_template = get_template(email_code + ".html")

    mail_content = html_template.render(context)
    return mail_content


def render_html_message(context, email_code, extra_args={}):
    # IDEA: Get model object using pk, fetch values and render into mail body

    html_template = get_template(email_code + ".html")
    if hasattr(context, "model_name") and hasattr(context, "app_name") and hasattr(context, "pk"):
        context_model = apps.get_model(
            context.app_name, context.model_name)
        context = context_model.objects.get(pk=context.request_id)

    # notice if you initiate a template using the Template class,
    # you need a Context dictionary, However making the template
    # using the get_template command, one can pass a dictionary

    context_dict = {'context': context}

    context_dict.update(extra_args)

    mail_content = html_template.render(context_dict)
    return mail_content
