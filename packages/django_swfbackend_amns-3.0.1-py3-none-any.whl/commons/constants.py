"""
constants.py - Common constants for the project
"""

PUBLISH_MAIL_DICT = {
    'mail_subject': "Default Subject",
    'mail_content': "An HTML Message",
    'to': 'emailaddress',
    'cc': 'emaladdress',
    'sender_email': 'another email',
    'mailserver': 'mailserver',
    'auth': False
}

