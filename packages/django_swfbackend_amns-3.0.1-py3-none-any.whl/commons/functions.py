import json
import random
import string
from datetime import datetime
from importlib import import_module

from django.core.paginator import Paginator



def create_child_objects(instance, validated_data, user):
    """
    Generic function to create reverse related objects after the parent object is saved
    """

    relations = instance._meta.related_objects
    edit_trail = {
        'created_by': user,
        'last_updated_by': user,
        'created_date': datetime.now(),
        'last_updated_date': datetime.now()
    }
    for each_relation in relations:
        related_model = each_relation.related_model
        related_name = each_relation.related_name
        fk_field_name = each_relation.field.name + '_id'
        validated_data_list = validated_data.pop(related_name, [])
        if validated_data_list:
            for each_json in validated_data_list:
                json.dumps(each_json, indent=2)
                each_json[fk_field_name] = instance.pk
                each_json.update(edit_trail)
                related_model.objects.create(**each_json)

def get_client_ip(request):
    """
    :param request: request object
    :return: ip str
    """
    x_forwarded_for = request.META.get('HTTP_X_FORWARDED_FOR')
    if x_forwarded_for:

        ip = x_forwarded_for.split(',')[-1].strip()
    elif request.META.get('HTTP_X_REAL_IP'):

        ip = request.META.get('HTTP_X_REAL_IP')
    else:

        ip = request.META.get('REMOTE_ADDR')
    return ip


def generate_random_string(length=8):
    return ''.join(
        random.choices(string.ascii_uppercase + string.digits, k=length))


def get_hooks(app, config_name, default_hook):
    """
    Function to get hook from app
    :param app: App name
    :param config_name: Config dictionary name
    :param default_hook: Default hook returned
    :return:
    """
    app_hook_path = app + ".hooks"
    try:
        app_hook = import_module(app_hook_path)
        hooks = getattr(app_hook, config_name, default_hook)

        return hooks
    except ImportError as exc:

        return default_hook


def get_paginated_queryset(queryset, limit, page=0):
    paginator = Paginator(queryset, limit)
    return paginator.page(page)