digest_header = {
    'accept': 'application/json; odata=verbose',
    'Content-Type': 'application/x-www-urlencoded; charset=UTF-8',
    'binaryStringRequestBody': 'true'
}

generic_header = {'Content-Type': 'application/x-www-urlencoded; charset=UTF-8',
           'accept': 'application/json;odata=verbose'
           }

rename_header = {
    "IF-MATCH": "*",
    "X-HTTP-Method": "MERGE",
    'accept': "application/json;odata=verbose",
    'Content-Type': "application/json;odata=verbose"
}

accept_header = {
            'accept': 'application/json;odata=verbose',
        }

delete_header = {
    "IF-MATCH": "*",
    "X-HTTP-Method": "DELETE",
    # 'accept': "application/json;odata=verbose",
    # 'Content-Type': "application/json;odata=verbose"
}

create_header =  {
            'Content-Type': 'application/x-www-urlencoded; charset=UTF-8',
            'accept': 'application/json;odata=verbose'
        }
