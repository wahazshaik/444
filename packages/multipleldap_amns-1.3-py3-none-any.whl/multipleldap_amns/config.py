"""
Configuration module for
Server's setup and
Logger directory path
"""

from .MultiLDAPAuthenticator import LDAPServer, MultipleLDAPAuthenticator


def configuration():
    """
    Setup the Multiple LDAP
    Server Objects
    """
    MultipleLDAPAuthenticator.setup(servers=[
        LDAPServer("MyAMNS","10.165.56.180", 389),
        LDAPServer("MyAMNS", "10.165.1.2", 389),
        LDAPServer("MyAMNS", "10.165.1.3", 389),]
    )






